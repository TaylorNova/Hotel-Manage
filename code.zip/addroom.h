#ifndef ADDROOM_H
#define ADDROOM_H

#include <QDialog>

namespace Ui {
class addroom;
}

class addroom : public QDialog
{
    Q_OBJECT

public:
    explicit addroom(QWidget *parent = 0);
    ~addroom();
    void paintEvent(QPaintEvent *event) override;

private slots:
    void on_confirm_clicked();

    void on_cancel_clicked();

    void on_choosepic_clicked();

private:
    Ui::addroom *ui;
};

#endif // ADDROOM_H
