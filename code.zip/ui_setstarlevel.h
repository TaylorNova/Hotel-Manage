/********************************************************************************
** Form generated from reading UI file 'setstarlevel.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETSTARLEVEL_H
#define UI_SETSTARLEVEL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>

QT_BEGIN_NAMESPACE

class Ui_setstarlevel
{
public:
    QTableWidget *view;
    QLabel *label;
    QComboBox *comboBox;
    QPushButton *confirm;
    QPushButton *cancel;

    void setupUi(QDialog *setstarlevel)
    {
        if (setstarlevel->objectName().isEmpty())
            setstarlevel->setObjectName(QStringLiteral("setstarlevel"));
        setstarlevel->resize(562, 507);
        view = new QTableWidget(setstarlevel);
        if (view->columnCount() < 4)
            view->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        view->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        view->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        view->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        view->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        view->setObjectName(QStringLiteral("view"));
        view->setGeometry(QRect(30, 30, 511, 251));
        view->setShowGrid(false);
        label = new QLabel(setstarlevel);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(90, 340, 101, 31));
        label->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        comboBox = new QComboBox(setstarlevel);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(270, 340, 141, 31));
        confirm = new QPushButton(setstarlevel);
        confirm->setObjectName(QStringLiteral("confirm"));
        confirm->setGeometry(QRect(120, 420, 101, 41));
        confirm->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        cancel = new QPushButton(setstarlevel);
        cancel->setObjectName(QStringLiteral("cancel"));
        cancel->setGeometry(QRect(340, 420, 101, 41));
        cancel->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));

        retranslateUi(setstarlevel);

        QMetaObject::connectSlotsByName(setstarlevel);
    } // setupUi

    void retranslateUi(QDialog *setstarlevel)
    {
        setstarlevel->setWindowTitle(QApplication::translate("setstarlevel", "\350\257\204\345\256\232\346\230\237\347\272\247", 0));
        QTableWidgetItem *___qtablewidgetitem = view->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("setstarlevel", "\346\210\277\345\236\213", 0));
        QTableWidgetItem *___qtablewidgetitem1 = view->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("setstarlevel", "\345\256\232\344\273\267", 0));
        QTableWidgetItem *___qtablewidgetitem2 = view->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("setstarlevel", "\344\274\230\346\203\240", 0));
        QTableWidgetItem *___qtablewidgetitem3 = view->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("setstarlevel", "\345\233\276\347\211\207", 0));
        label->setText(QApplication::translate("setstarlevel", "\350\257\204\345\256\232\346\230\237\347\272\247", 0));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("setstarlevel", "\344\272\224\346\230\237\347\272\247", 0)
         << QApplication::translate("setstarlevel", "\345\233\233\346\230\237\347\272\247", 0)
         << QApplication::translate("setstarlevel", "\344\270\211\346\230\237\347\272\247", 0)
         << QApplication::translate("setstarlevel", "\344\272\214\346\230\237\347\272\247", 0)
         << QApplication::translate("setstarlevel", "\344\270\200\346\230\237\347\272\247", 0)
        );
        confirm->setText(QApplication::translate("setstarlevel", "\347\241\256\350\256\244", 0));
        cancel->setText(QApplication::translate("setstarlevel", "\345\217\226\346\266\210", 0));
    } // retranslateUi

};

namespace Ui {
    class setstarlevel: public Ui_setstarlevel {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETSTARLEVEL_H
