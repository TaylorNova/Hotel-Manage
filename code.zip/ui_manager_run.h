/********************************************************************************
** Form generated from reading UI file 'manager_run.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MANAGER_RUN_H
#define UI_MANAGER_RUN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>

QT_BEGIN_NAMESPACE

class Ui_manager_run
{
public:
    QPushButton *back;
    QTableWidget *tableWidget;
    QLabel *label;
    QPushButton *look;

    void setupUi(QDialog *manager_run)
    {
        if (manager_run->objectName().isEmpty())
            manager_run->setObjectName(QStringLiteral("manager_run"));
        manager_run->resize(552, 448);
        back = new QPushButton(manager_run);
        back->setObjectName(QStringLiteral("back"));
        back->setGeometry(QRect(330, 350, 101, 41));
        back->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        tableWidget = new QTableWidget(manager_run);
        if (tableWidget->columnCount() < 4)
            tableWidget->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        tableWidget->setObjectName(QStringLiteral("tableWidget"));
        tableWidget->setGeometry(QRect(20, 50, 521, 261));
        tableWidget->setShowGrid(false);
        label = new QLabel(manager_run);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(30, 0, 121, 41));
        label->setStyleSheet(QString::fromUtf8("font: 25 14pt \"\346\226\271\346\255\243\347\273\217\351\273\221\347\256\200\344\275\223\";"));
        look = new QPushButton(manager_run);
        look->setObjectName(QStringLiteral("look"));
        look->setGeometry(QRect(110, 350, 101, 41));
        look->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));

        retranslateUi(manager_run);

        QMetaObject::connectSlotsByName(manager_run);
    } // setupUi

    void retranslateUi(QDialog *manager_run)
    {
        manager_run->setWindowTitle(QApplication::translate("manager_run", "\347\256\241\347\220\206\345\221\230", 0));
        back->setText(QApplication::translate("manager_run", "\350\277\224\345\233\236", 0));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("manager_run", "\347\224\250\346\210\267", 0));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("manager_run", "\346\210\277\345\236\213", 0));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("manager_run", "\346\200\273\351\207\221\351\242\235", 0));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("manager_run", "\351\200\211\346\213\251", 0));
        label->setText(QApplication::translate("manager_run", "\347\256\241\347\220\206\350\256\242\345\215\225", 0));
        look->setText(QApplication::translate("manager_run", "\346\237\245\347\234\213", 0));
    } // retranslateUi

};

namespace Ui {
    class manager_run: public Ui_manager_run {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MANAGER_RUN_H
