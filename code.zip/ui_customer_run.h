/********************************************************************************
** Form generated from reading UI file 'customer_run.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CUSTOMER_RUN_H
#define UI_CUSTOMER_RUN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_customer_run
{
public:
    QTabWidget *tabWidget;
    QWidget *tab;
    QPushButton *back;
    QPushButton *find;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QComboBox *city;
    QComboBox *area;
    QComboBox *star;
    QWidget *tab_2;
    QTableWidget *tableWidget;
    QPushButton *look;
    QPushButton *back_2;
    QLabel *label_4;
    QPushButton *fresh;

    void setupUi(QDialog *customer_run)
    {
        if (customer_run->objectName().isEmpty())
            customer_run->setObjectName(QStringLiteral("customer_run"));
        customer_run->resize(660, 538);
        tabWidget = new QTabWidget(customer_run);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 661, 541));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        back = new QPushButton(tab);
        back->setObjectName(QStringLiteral("back"));
        back->setGeometry(QRect(420, 380, 101, 41));
        back->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        find = new QPushButton(tab);
        find->setObjectName(QStringLiteral("find"));
        find->setGeometry(QRect(130, 380, 101, 41));
        find->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        label = new QLabel(tab);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(170, 80, 101, 41));
        label->setStyleSheet(QString::fromUtf8("font: 20pt \"\346\226\271\346\255\243\345\221\220\345\226\212\344\275\223\";"));
        label_2 = new QLabel(tab);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(170, 160, 91, 61));
        label_2->setStyleSheet(QString::fromUtf8("font: 20pt \"\346\226\271\346\255\243\345\221\220\345\226\212\344\275\223\";"));
        label_3 = new QLabel(tab);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(170, 260, 81, 41));
        label_3->setStyleSheet(QString::fromUtf8("font: 20pt \"\346\226\271\346\255\243\345\221\220\345\226\212\344\275\223\";"));
        city = new QComboBox(tab);
        city->setObjectName(QStringLiteral("city"));
        city->setGeometry(QRect(330, 80, 141, 31));
        city->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        area = new QComboBox(tab);
        area->setObjectName(QStringLiteral("area"));
        area->setGeometry(QRect(330, 170, 141, 31));
        area->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        star = new QComboBox(tab);
        star->setObjectName(QStringLiteral("star"));
        star->setGeometry(QRect(330, 270, 141, 31));
        star->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        tableWidget = new QTableWidget(tab_2);
        if (tableWidget->columnCount() < 5)
            tableWidget->setColumnCount(5);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        tableWidget->setObjectName(QStringLiteral("tableWidget"));
        tableWidget->setGeometry(QRect(10, 60, 641, 301));
        tableWidget->setShowGrid(false);
        look = new QPushButton(tab_2);
        look->setObjectName(QStringLiteral("look"));
        look->setGeometry(QRect(140, 420, 101, 41));
        look->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        back_2 = new QPushButton(tab_2);
        back_2->setObjectName(QStringLiteral("back_2"));
        back_2->setGeometry(QRect(380, 420, 101, 41));
        back_2->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        label_4 = new QLabel(tab_2);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(20, 10, 111, 41));
        label_4->setStyleSheet(QString::fromUtf8("font: 25 14pt \"\346\226\271\346\255\243\347\273\217\351\273\221\347\256\200\344\275\223\";"));
        fresh = new QPushButton(tab_2);
        fresh->setObjectName(QStringLiteral("fresh"));
        fresh->setGeometry(QRect(520, 370, 101, 41));
        fresh->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        tabWidget->addTab(tab_2, QString());

        retranslateUi(customer_run);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(customer_run);
    } // setupUi

    void retranslateUi(QDialog *customer_run)
    {
        customer_run->setWindowTitle(QApplication::translate("customer_run", "\351\241\276\345\256\242", 0));
        back->setText(QApplication::translate("customer_run", "\350\277\224\345\233\236", 0));
        find->setText(QApplication::translate("customer_run", "\346\237\245\350\257\242", 0));
        label->setText(QApplication::translate("customer_run", "\345\237\216\345\270\202", 0));
        label_2->setText(QApplication::translate("customer_run", "\345\234\260\345\214\272", 0));
        label_3->setText(QApplication::translate("customer_run", "\346\230\237\347\272\247", 0));
        city->clear();
        city->insertItems(0, QStringList()
         << QApplication::translate("customer_run", "\345\214\227\344\272\254", 0)
         << QApplication::translate("customer_run", "\344\270\212\346\265\267", 0)
        );
        area->clear();
        area->insertItems(0, QStringList()
         << QApplication::translate("customer_run", "\346\265\267\346\267\200\345\214\272", 0)
         << QApplication::translate("customer_run", "\346\234\235\351\230\263\345\214\272", 0)
        );
        star->clear();
        star->insertItems(0, QStringList()
         << QApplication::translate("customer_run", "\344\272\224\346\230\237\347\272\247", 0)
         << QApplication::translate("customer_run", "\345\233\233\346\230\237\347\272\247", 0)
         << QApplication::translate("customer_run", "\344\270\211\346\230\237\347\272\247", 0)
         << QApplication::translate("customer_run", "\344\272\214\346\230\237\347\272\247", 0)
         << QApplication::translate("customer_run", "\344\270\200\346\230\237\347\272\247", 0)
        );
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("customer_run", "\346\237\245\350\257\242", 0));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("customer_run", "\351\205\222\345\272\227", 0));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("customer_run", "\346\210\277\345\236\213", 0));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("customer_run", "\345\215\225\351\227\264", 0));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("customer_run", "\347\212\266\346\200\201", 0));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("customer_run", "\351\200\211\346\213\251", 0));
        look->setText(QApplication::translate("customer_run", "\346\237\245\347\234\213", 0));
        back_2->setText(QApplication::translate("customer_run", "\345\217\226\346\266\210", 0));
        label_4->setText(QApplication::translate("customer_run", "\346\210\221\347\232\204\350\256\242\345\215\225", 0));
        fresh->setText(QApplication::translate("customer_run", "\345\210\267\346\226\260", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("customer_run", "\350\256\242\345\215\225", 0));
    } // retranslateUi

};

namespace Ui {
    class customer_run: public Ui_customer_run {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CUSTOMER_RUN_H
