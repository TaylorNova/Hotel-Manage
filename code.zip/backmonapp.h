#ifndef BACKMONAPP_H
#define BACKMONAPP_H

#include <QDialog>

namespace Ui {
class backmonapp;
}

class backmonapp : public QDialog
{
    Q_OBJECT

public:
    explicit backmonapp(QWidget *parent = 0);
    ~backmonapp();

private slots:
    void on_confirm_clicked();

    void on_cancel_clicked();

private:
    Ui::backmonapp *ui;
};

#endif // BACKMONAPP_H
