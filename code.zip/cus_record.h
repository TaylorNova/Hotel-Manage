#ifndef CUS_RECORD_H
#define CUS_RECORD_H

#include "all_headers_nedded.h"

class Record
{
public:
    Record();
    ~Record();
    void set_choose_city(QString its_choose_city);
    void set_choose_area(QString its_choose_area);
    void set_choose_star(QString its_choose_star);
    QString get_choose_city () const;
    QString get_choose_area () const;
    QString get_choose_star () const;
private:
    QString choose_city;
    QString choose_area;
    QString choose_star;
};
#endif // CUS_RECORD_H
