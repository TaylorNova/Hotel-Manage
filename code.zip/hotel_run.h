#ifndef HOTEL_RUN_H
#define HOTEL_RUN_H

#include <QDialog>
#include "all_headers_nedded.h"
#include "room.h"
#include "data.h"

namespace Ui {
class hotel_run;
}

class hotel_run : public QDialog
{
    Q_OBJECT

public:
    explicit hotel_run(QWidget *parent = 0);
    ~hotel_run();
    void paintEvent(QPaintEvent *event) override;
    void closeEvent(QCloseEvent * event);

private slots:
    void on_back_clicked();

    void on_add_clicked();

    void on_change_clicked();

private:
    Ui::hotel_run *ui;
};

#endif // HOTEL_RUN_H
