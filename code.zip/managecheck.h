#ifndef MANAGECHECK_H
#define MANAGECHECK_H

#include <QDialog>

namespace Ui {
class managecheck;
}

class managecheck : public QDialog
{
    Q_OBJECT

public:
    explicit managecheck(QWidget *parent = 0);
    ~managecheck();
    void paintEvent(QPaintEvent *event) override;

private slots:
    void on_back_clicked();

    void on_bamoncon_clicked();

    void on_constaystate_clicked();

private:
    Ui::managecheck *ui;
};

#endif // MANAGECHECK_H
