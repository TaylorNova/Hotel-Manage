#ifndef ALL_HEADERS_NEDDED_H
#define ALL_HEADERS_NEDDED_H

#include <QMessageBox>
#include <QSqlDatabase>
#include <QSharedData>
#include <QSqlQuery>
#include <QDialog>
#include <QMainWindow>
#include <QApplication>
#include <QSqlQueryModel>
#include <QSqlTableModel>
#include <QSqlRelationalTableModel>
#include <QTableView>
#include <QDebug>
#include <QMessageBox>
#include <QSqlError>
#include <QMainWindow>
#include <QLayout>
#include <QLabel>
#include <QString>
#include <QPushButton>
#include <iostream>
#include <QCloseEvent>
#include <vector>

#endif // ALL_HEADERS_NEDDED_H
