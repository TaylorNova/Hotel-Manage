#ifndef CUSTOMER_RUN_H
#define CUSTOMER_RUN_H

#include <QDialog>
#include "all_headers_nedded.h"

namespace Ui {
class customer_run;
}

class customer_run : public QDialog
{
    Q_OBJECT

public:
    explicit customer_run(QWidget *parent = 0);
    ~customer_run();
    void paintEvent(QPaintEvent *event) override;
    void closeEvent(QCloseEvent * event);

private slots:
    void on_back_clicked();

    void on_find_clicked();

    void on_fresh_clicked();

    void on_look_clicked();

    void on_back_2_clicked();

private:
    Ui::customer_run *ui;
};

#endif // CUSTOMER_RUN_H
