/********************************************************************************
** Form generated from reading UI file 'confirmpass.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONFIRMPASS_H
#define UI_CONFIRMPASS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_confirmpass
{
public:
    QLabel *label;
    QPushButton *confirm;
    QPushButton *cancel;

    void setupUi(QDialog *confirmpass)
    {
        if (confirmpass->objectName().isEmpty())
            confirmpass->setObjectName(QStringLiteral("confirmpass"));
        confirmpass->resize(400, 300);
        label = new QLabel(confirmpass);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(100, 60, 251, 101));
        label->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        confirm = new QPushButton(confirmpass);
        confirm->setObjectName(QStringLiteral("confirm"));
        confirm->setGeometry(QRect(50, 180, 101, 41));
        confirm->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        cancel = new QPushButton(confirmpass);
        cancel->setObjectName(QStringLiteral("cancel"));
        cancel->setGeometry(QRect(240, 180, 101, 41));
        cancel->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));

        retranslateUi(confirmpass);

        QMetaObject::connectSlotsByName(confirmpass);
    } // setupUi

    void retranslateUi(QDialog *confirmpass)
    {
        confirmpass->setWindowTitle(QApplication::translate("confirmpass", "\346\217\220\347\244\272", 0));
        label->setText(QApplication::translate("confirmpass", "\347\241\256\350\256\244\350\256\251\350\257\245\351\205\222\345\272\227\351\200\232\350\277\207\345\256\241\346\240\270\357\274\237", 0));
        confirm->setText(QApplication::translate("confirmpass", "\347\241\256\350\256\244", 0));
        cancel->setText(QApplication::translate("confirmpass", "\345\217\226\346\266\210", 0));
    } // retranslateUi

};

namespace Ui {
    class confirmpass: public Ui_confirmpass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONFIRMPASS_H
