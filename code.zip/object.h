#ifndef OBJECT_H
#define OBJECT_H
#include "all_headers_nedded.h"
#include <iostream>
using namespace std;

class Object
{
public:
    Object();
    ~Object();
    virtual void set_name(QString &its_name);
    virtual void set_id(int its_id);
    virtual QString get_name() const;
    virtual int get_id() const;
protected:
    QString name = "";
    int id = 0;
};

#endif // OBJECT_H
