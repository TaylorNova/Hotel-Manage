/********************************************************************************
** Form generated from reading UI file 'addroom.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDROOM_H
#define UI_ADDROOM_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>

QT_BEGIN_NAMESPACE

class Ui_addroom
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QComboBox *type;
    QComboBox *discount;
    QSpinBox *lastnum;
    QLineEdit *price;
    QPushButton *confirm;
    QPushButton *cancel;
    QLabel *picture;
    QPushButton *choosepic;
    QLabel *label_6;
    QLineEdit *description;

    void setupUi(QDialog *addroom)
    {
        if (addroom->objectName().isEmpty())
            addroom->setObjectName(QStringLiteral("addroom"));
        addroom->resize(490, 492);
        label = new QLabel(addroom);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(90, 20, 71, 21));
        label->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_2 = new QLabel(addroom);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(90, 60, 71, 21));
        label_2->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_3 = new QLabel(addroom);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(90, 100, 71, 21));
        label_3->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_4 = new QLabel(addroom);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(90, 140, 71, 21));
        label_4->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_5 = new QLabel(addroom);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(90, 230, 71, 21));
        label_5->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        type = new QComboBox(addroom);
        type->setObjectName(QStringLiteral("type"));
        type->setGeometry(QRect(210, 20, 121, 22));
        discount = new QComboBox(addroom);
        discount->setObjectName(QStringLiteral("discount"));
        discount->setGeometry(QRect(210, 100, 87, 22));
        lastnum = new QSpinBox(addroom);
        lastnum->setObjectName(QStringLiteral("lastnum"));
        lastnum->setGeometry(QRect(210, 140, 41, 22));
        lastnum->setStyleSheet(QLatin1String("QTimeEdit::up-button,QDoubleSpinBox::up-button,QSpinBox::up-button {subcontrol-origin:border;\n"
"    subcontrol-position:right;\n"
"    image: url(:/Image/right.png);\n"
"    width: 12px;\n"
"    height: 20px;       \n"
"}\n"
"QTimeEdit::down-button,QDoubleSpinBox::down-button,QSpinBox::down-button {subcontrol-origin:border;\n"
"    subcontrol-position:left;\n"
"    image: url(:/Image/left.png);\n"
"    width: 12px;\n"
"    height: 20px;\n"
"}\n"
"QTimeEdit::up-button:pressed,QDoubleSpinBox::up-button:pressed,QSpinBox::up-button:pressed{subcontrol-origin:border;\n"
"    subcontrol-position:right;\n"
"    image: url(:/Image/right1.png);\n"
"    width: 12px;\n"
"    height: 20px;       \n"
"}\n"
"  \n"
"QTimeEdit::down-button:pressed,QDoubleSpinBox::down-button:pressed,QSpinBox::down-button:pressed,QSpinBox::down-button:pressed{\n"
"    subcontrol-position:left;\n"
"    image: url(:/Image/left1.png);\n"
"    width: 12px;\n"
"    height: 20px;\n"
"}"));
        price = new QLineEdit(addroom);
        price->setObjectName(QStringLiteral("price"));
        price->setGeometry(QRect(210, 60, 113, 21));
        price->setStyleSheet(QStringLiteral("border:2px groove gray;border-radius:10px;padding:2px 4px"));
        confirm = new QPushButton(addroom);
        confirm->setObjectName(QStringLiteral("confirm"));
        confirm->setGeometry(QRect(80, 430, 101, 41));
        confirm->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        cancel = new QPushButton(addroom);
        cancel->setObjectName(QStringLiteral("cancel"));
        cancel->setGeometry(QRect(290, 430, 101, 41));
        cancel->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        picture = new QLabel(addroom);
        picture->setObjectName(QStringLiteral("picture"));
        picture->setGeometry(QRect(220, 270, 231, 141));
        picture->setScaledContents(true);
        choosepic = new QPushButton(addroom);
        choosepic->setObjectName(QStringLiteral("choosepic"));
        choosepic->setGeometry(QRect(210, 220, 101, 51));
        choosepic->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang13.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang15.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang16.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        label_6 = new QLabel(addroom);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(90, 180, 41, 21));
        label_6->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        description = new QLineEdit(addroom);
        description->setObjectName(QStringLiteral("description"));
        description->setGeometry(QRect(210, 180, 251, 21));
        description->setStyleSheet(QStringLiteral("border:2px groove gray;border-radius:10px;padding:2px 4px"));

        retranslateUi(addroom);

        QMetaObject::connectSlotsByName(addroom);
    } // setupUi

    void retranslateUi(QDialog *addroom)
    {
        addroom->setWindowTitle(QApplication::translate("addroom", "\346\267\273\345\212\240\345\256\242\346\210\277", 0));
        label->setText(QApplication::translate("addroom", "\346\210\277\345\236\213", 0));
        label_2->setText(QApplication::translate("addroom", "\345\256\232\344\273\267", 0));
        label_3->setText(QApplication::translate("addroom", "\344\274\230\346\203\240", 0));
        label_4->setText(QApplication::translate("addroom", "\344\275\231\351\207\217", 0));
        label_5->setText(QApplication::translate("addroom", "\345\233\276\347\211\207", 0));
        type->clear();
        type->insertItems(0, QStringList()
         << QApplication::translate("addroom", "\345\215\225\344\272\272\351\227\264", 0)
         << QApplication::translate("addroom", "\346\240\207\345\207\206\351\227\264", 0)
         << QApplication::translate("addroom", "\350\261\252\345\215\216\345\215\225\344\272\272\351\227\264", 0)
         << QApplication::translate("addroom", "\350\261\252\345\215\216\346\240\207\345\207\206\351\227\264", 0)
         << QApplication::translate("addroom", "\345\256\266\345\272\255\345\245\227\346\210\277", 0)
         << QApplication::translate("addroom", "\346\200\273\347\273\237\345\245\227\346\210\277", 0)
        );
        discount->clear();
        discount->insertItems(0, QStringList()
         << QApplication::translate("addroom", "\346\227\240", 0)
         << QApplication::translate("addroom", "9\346\212\230", 0)
         << QApplication::translate("addroom", "8\346\212\230", 0)
         << QApplication::translate("addroom", "7\346\212\230", 0)
         << QApplication::translate("addroom", "6\346\212\230", 0)
         << QApplication::translate("addroom", "5\346\212\230", 0)
        );
        confirm->setText(QApplication::translate("addroom", "\347\241\256\350\256\244", 0));
        cancel->setText(QApplication::translate("addroom", "\345\217\226\346\266\210", 0));
        picture->setText(QApplication::translate("addroom", "TextLabel", 0));
        choosepic->setText(QApplication::translate("addroom", "\351\200\211\346\213\251\345\233\276\347\211\207", 0));
        label_6->setText(QApplication::translate("addroom", "\346\217\217\350\277\260", 0));
    } // retranslateUi

};

namespace Ui {
    class addroom: public Ui_addroom {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDROOM_H
