#ifndef ROOM_H
#define ROOM_H

#include "all_headers_nedded.h"
#include <iostream>
#include "Object.h"
using namespace std;
class Room : public Object
{
public:
    Room();
    Room(Room &ro1);
    ~Room();
    void set_type(QString its_type);
    void set_discount(QString its_discount);
    void set_price(int its_price);
    void set_lastnum(int its_lastnum);
    void set_picture(QString its_picture);
    void set_hotelname(QString its_hotelname);
    void set_description(QString its_description);
    QString get_type() const;
    QString get_discount() const;
    int get_price() const;
    int get_lastnum() const;
    QString get_picture() const;
    QString get_hotelname() const;
    QString get_description() const;
private:
    QString type;
    QString discount;
    int price;
    int lastnum;
    QString picture;
    QString hotelname;
    QString description;
};


#endif // ROOM_H
