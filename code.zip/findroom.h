#ifndef FINDROOM_H
#define FINDROOM_H

#include <QDialog>

namespace Ui {
class findroom;
}

class findroom : public QDialog
{
    Q_OBJECT

public:
    explicit findroom(QWidget *parent = 0);
    ~findroom();
    void paintEvent(QPaintEvent *event) override;

private slots:
    void on_pushButton_2_clicked();

    void on_details_clicked();

    void on_sort_clicked();

private:
    Ui::findroom *ui;
};

#endif // FINDROOM_H
