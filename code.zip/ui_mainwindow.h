/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QPushButton *registering;
    QLabel *label_phonenum;
    QLabel *label_password;
    QLabel *label_class;
    QComboBox *comboBox;
    QLineEdit *lineEdit_phnum;
    QLineEdit *lineEdit_psw;
    QPushButton *login;
    QPushButton *cancel;
    QLabel *label_4;
    QLabel *label;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(651, 503);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        registering = new QPushButton(centralWidget);
        registering->setObjectName(QStringLiteral("registering"));
        registering->setGeometry(QRect(330, 380, 121, 51));
        registering->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kua4.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(122, 56, 3)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kua5.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(244, 234, 41)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kua3.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(153, 94, 30)\n"
"}"));
        label_phonenum = new QLabel(centralWidget);
        label_phonenum->setObjectName(QStringLiteral("label_phonenum"));
        label_phonenum->setGeometry(QRect(150, 140, 141, 41));
        label_phonenum->setStyleSheet(QString::fromUtf8("font: 75 12pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(94, 213, 238);"));
        label_password = new QLabel(centralWidget);
        label_password->setObjectName(QStringLiteral("label_password"));
        label_password->setGeometry(QRect(170, 210, 21, 20));
        label_password->setStyleSheet(QString::fromUtf8("font: 75 12pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(94, 213, 238);"));
        label_class = new QLabel(centralWidget);
        label_class->setObjectName(QStringLiteral("label_class"));
        label_class->setGeometry(QRect(150, 90, 101, 31));
        label_class->setStyleSheet(QString::fromUtf8("font: 75 12pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(94, 213, 238);"));
        comboBox = new QComboBox(centralWidget);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(300, 90, 161, 31));
        comboBox->setStyleSheet(QString::fromUtf8("font: 9pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        lineEdit_phnum = new QLineEdit(centralWidget);
        lineEdit_phnum->setObjectName(QStringLiteral("lineEdit_phnum"));
        lineEdit_phnum->setGeometry(QRect(300, 140, 161, 31));
        lineEdit_phnum->setStyleSheet(QStringLiteral("border:2px groove gray;border-radius:10px;padding:2px 4px"));
        lineEdit_psw = new QLineEdit(centralWidget);
        lineEdit_psw->setObjectName(QStringLiteral("lineEdit_psw"));
        lineEdit_psw->setGeometry(QRect(300, 200, 161, 31));
        lineEdit_psw->setStyleSheet(QStringLiteral("border:2px groove gray;border-radius:10px;padding:2px 4px"));
        lineEdit_psw->setEchoMode(QLineEdit::Password);
        login = new QPushButton(centralWidget);
        login->setObjectName(QStringLiteral("login"));
        login->setGeometry(QRect(170, 320, 121, 41));
        login->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang4.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(213, 108, 15)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang6.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(244, 234, 41)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang7.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(153, 94, 30)\n"
"}"));
        cancel = new QPushButton(centralWidget);
        cancel->setObjectName(QStringLiteral("cancel"));
        cancel->setGeometry(QRect(350, 320, 121, 41));
        cancel->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang4.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(213, 108, 15)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang6.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(244, 234, 41)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang7.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(153, 94, 30)\n"
"}"));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(200, 390, 101, 31));
        label_4->setStyleSheet(QString::fromUtf8("color:rgb(13, 158, 189);\n"
"font: 75 12pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(150, 210, 21, 21));
        label->setStyleSheet(QString::fromUtf8("color:rgb(10, 74, 88);\n"
"font: 75 12pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
""));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 651, 26));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);
        QObject::connect(cancel, SIGNAL(clicked()), MainWindow, SLOT(close()));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "hotels in clouds", 0));
        registering->setText(QApplication::translate("MainWindow", "\346\263\250\345\206\214", 0));
        label_phonenum->setText(QApplication::translate("MainWindow", "\347\224\250\346\210\267\345\220\215\357\274\210\346\211\213\346\234\272\357\274\211", 0));
        label_password->setText(QApplication::translate("MainWindow", "\347\240\201", 0));
        label_class->setText(QApplication::translate("MainWindow", "\347\224\250\346\210\267\347\261\273\345\236\213", 0));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "\351\241\276\345\256\242", 0)
         << QApplication::translate("MainWindow", "\347\256\241\347\220\206\345\221\230", 0)
         << QApplication::translate("MainWindow", "\351\205\222\345\272\227", 0)
         << QApplication::translate("MainWindow", "\345\271\263\345\217\260", 0)
        );
        login->setText(QApplication::translate("MainWindow", "\347\231\273\345\275\225", 0));
        cancel->setText(QApplication::translate("MainWindow", "\345\217\226\346\266\210", 0));
        label_4->setText(QApplication::translate("MainWindow", "\346\262\241\346\234\211\350\264\246\345\217\267\357\274\237", 0));
        label->setText(QApplication::translate("MainWindow", "\345\257\206", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
