#ifndef SEEROOM_H
#define SEEROOM_H

#include <QDialog>

namespace Ui {
class seeroom;
}

class seeroom : public QDialog
{
    Q_OBJECT

public:
    explicit seeroom(QWidget *parent = 0);
    ~seeroom();
    void paintEvent(QPaintEvent *event) override;

private slots:
    void on_cancel_clicked();

    void on_sort_down_clicked();

    void on_sort_up_clicked();

    void on_order_clicked();

private:
    Ui::seeroom *ui;
};

#endif // SEEROOM_H
