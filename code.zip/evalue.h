#ifndef EVALUE_H
#define EVALUE_H

#include "all_headers_nedded.h"
#include <iostream>
using namespace std;

class Evalue
{
public:
    Evalue();
    ~Evalue();
    void set_hotelname(QString its_hotelname);
    void set_score(float its_score);
    void set_number(int its_number);
    void renew_score(float new_score);
    QString get_hotelname() const;
    float get_score() const;
    int get_number() const;
private:
    QString hotelname;
    float score;
    int number;
};

#endif // EVALUE_H
