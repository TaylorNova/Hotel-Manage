#ifndef CUSTOMER_H
#define CUSTOMER_H

#include "all_headers_nedded.h"
#include <iostream>
#include "People.h"
#include "Order.h"
using namespace std;
class Customer : public People
{
public:
    Customer();
    ~Customer();
    void set_myorder(Order &its_myorder);
    Order & get_myorder();
private:
    Order myorder;
};

#endif // CUSTOMER_H
