/********************************************************************************
** Form generated from reading UI file 'changeroom.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHANGEROOM_H
#define UI_CHANGEROOM_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>

QT_BEGIN_NAMESPACE

class Ui_changeroom
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QPushButton *confirm;
    QPushButton *cancel;
    QLineEdit *price;
    QComboBox *discount;
    QSpinBox *lastnum;
    QLabel *roomtype;
    QLabel *picture;
    QPushButton *pushButton;
    QLabel *label_6;
    QLineEdit *description;

    void setupUi(QDialog *changeroom)
    {
        if (changeroom->objectName().isEmpty())
            changeroom->setObjectName(QStringLiteral("changeroom"));
        changeroom->resize(513, 519);
        label = new QLabel(changeroom);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(100, 20, 71, 21));
        label->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_2 = new QLabel(changeroom);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(100, 60, 71, 21));
        label_2->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_3 = new QLabel(changeroom);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(100, 100, 71, 21));
        label_3->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_4 = new QLabel(changeroom);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(100, 140, 71, 21));
        label_4->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_5 = new QLabel(changeroom);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(100, 230, 71, 21));
        label_5->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        confirm = new QPushButton(changeroom);
        confirm->setObjectName(QStringLiteral("confirm"));
        confirm->setGeometry(QRect(90, 450, 101, 41));
        confirm->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        cancel = new QPushButton(changeroom);
        cancel->setObjectName(QStringLiteral("cancel"));
        cancel->setGeometry(QRect(320, 450, 101, 41));
        cancel->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        price = new QLineEdit(changeroom);
        price->setObjectName(QStringLiteral("price"));
        price->setGeometry(QRect(230, 60, 113, 21));
        price->setStyleSheet(QStringLiteral("border:2px groove gray;border-radius:10px;padding:2px 4px"));
        discount = new QComboBox(changeroom);
        discount->setObjectName(QStringLiteral("discount"));
        discount->setGeometry(QRect(230, 100, 87, 22));
        lastnum = new QSpinBox(changeroom);
        lastnum->setObjectName(QStringLiteral("lastnum"));
        lastnum->setGeometry(QRect(230, 140, 41, 22));
        lastnum->setStyleSheet(QLatin1String("QTimeEdit::up-button,QDoubleSpinBox::up-button,QSpinBox::up-button {subcontrol-origin:border;\n"
"    subcontrol-position:right;\n"
"    image: url(:/Image/right.png);\n"
"    width: 12px;\n"
"    height: 20px;       \n"
"}\n"
"QTimeEdit::down-button,QDoubleSpinBox::down-button,QSpinBox::down-button {subcontrol-origin:border;\n"
"    subcontrol-position:left;\n"
"    image: url(:/Image/left.png);\n"
"    width: 12px;\n"
"    height: 20px;\n"
"}\n"
"QTimeEdit::up-button:pressed,QDoubleSpinBox::up-button:pressed,QSpinBox::up-button:pressed{subcontrol-origin:border;\n"
"    subcontrol-position:right;\n"
"    image: url(:/Image/right1.png);\n"
"    width: 12px;\n"
"    height: 20px;       \n"
"}\n"
"  \n"
"QTimeEdit::down-button:pressed,QDoubleSpinBox::down-button:pressed,QSpinBox::down-button:pressed,QSpinBox::down-button:pressed{\n"
"    subcontrol-position:left;\n"
"    image: url(:/Image/left1.png);\n"
"    width: 12px;\n"
"    height: 20px;\n"
"}"));
        roomtype = new QLabel(changeroom);
        roomtype->setObjectName(QStringLiteral("roomtype"));
        roomtype->setGeometry(QRect(230, 20, 101, 21));
        roomtype->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        picture = new QLabel(changeroom);
        picture->setObjectName(QStringLiteral("picture"));
        picture->setGeometry(QRect(220, 290, 221, 141));
        picture->setScaledContents(true);
        pushButton = new QPushButton(changeroom);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(230, 220, 101, 51));
        pushButton->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang13.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang15.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang16.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        label_6 = new QLabel(changeroom);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(100, 180, 51, 31));
        label_6->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        description = new QLineEdit(changeroom);
        description->setObjectName(QStringLiteral("description"));
        description->setGeometry(QRect(230, 180, 241, 31));
        description->setStyleSheet(QStringLiteral("border:2px groove gray;border-radius:10px;padding:2px 4px"));

        retranslateUi(changeroom);

        QMetaObject::connectSlotsByName(changeroom);
    } // setupUi

    void retranslateUi(QDialog *changeroom)
    {
        changeroom->setWindowTitle(QApplication::translate("changeroom", "\344\277\256\346\224\271\345\256\242\346\210\277\344\277\241\346\201\257", 0));
        label->setText(QApplication::translate("changeroom", "\346\210\277\345\236\213", 0));
        label_2->setText(QApplication::translate("changeroom", "\345\256\232\344\273\267", 0));
        label_3->setText(QApplication::translate("changeroom", "\344\274\230\346\203\240", 0));
        label_4->setText(QApplication::translate("changeroom", "\344\275\231\351\207\217", 0));
        label_5->setText(QApplication::translate("changeroom", "\345\233\276\347\211\207", 0));
        confirm->setText(QApplication::translate("changeroom", "\347\241\256\350\256\244", 0));
        cancel->setText(QApplication::translate("changeroom", "\345\217\226\346\266\210", 0));
        discount->clear();
        discount->insertItems(0, QStringList()
         << QApplication::translate("changeroom", "\346\227\240", 0)
         << QApplication::translate("changeroom", "9\346\212\230", 0)
         << QApplication::translate("changeroom", "8\346\212\230", 0)
         << QApplication::translate("changeroom", "7\346\212\230", 0)
         << QApplication::translate("changeroom", "6\346\212\230", 0)
         << QApplication::translate("changeroom", "5\346\212\230", 0)
        );
        roomtype->setText(QString());
        picture->setText(QApplication::translate("changeroom", "TextLabel", 0));
        pushButton->setText(QApplication::translate("changeroom", "\351\200\211\346\213\251\345\233\276\347\211\207", 0));
        label_6->setText(QApplication::translate("changeroom", "\346\217\217\350\277\260", 0));
    } // retranslateUi

};

namespace Ui {
    class changeroom: public Ui_changeroom {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHANGEROOM_H
