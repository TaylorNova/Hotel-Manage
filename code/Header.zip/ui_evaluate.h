/********************************************************************************
** Form generated from reading UI file 'evaluate.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EVALUATE_H
#define UI_EVALUATE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_evaluate
{
public:
    QLabel *label;
    QPushButton *star1;
    QPushButton *star2;
    QPushButton *star3;
    QPushButton *star4;
    QPushButton *star5;
    QPushButton *confirm;
    QPushButton *cancel;

    void setupUi(QDialog *evaluate)
    {
        if (evaluate->objectName().isEmpty())
            evaluate->setObjectName(QStringLiteral("evaluate"));
        evaluate->resize(331, 255);
        label = new QLabel(evaluate);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 10, 211, 31));
        label->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        star1 = new QPushButton(evaluate);
        star1->setObjectName(QStringLiteral("star1"));
        star1->setGeometry(QRect(30, 90, 31, 28));
        star2 = new QPushButton(evaluate);
        star2->setObjectName(QStringLiteral("star2"));
        star2->setGeometry(QRect(80, 90, 31, 28));
        star3 = new QPushButton(evaluate);
        star3->setObjectName(QStringLiteral("star3"));
        star3->setGeometry(QRect(130, 90, 31, 28));
        star4 = new QPushButton(evaluate);
        star4->setObjectName(QStringLiteral("star4"));
        star4->setGeometry(QRect(180, 90, 31, 28));
        star5 = new QPushButton(evaluate);
        star5->setObjectName(QStringLiteral("star5"));
        star5->setGeometry(QRect(230, 90, 31, 28));
        confirm = new QPushButton(evaluate);
        confirm->setObjectName(QStringLiteral("confirm"));
        confirm->setGeometry(QRect(60, 180, 71, 41));
        confirm->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        cancel = new QPushButton(evaluate);
        cancel->setObjectName(QStringLiteral("cancel"));
        cancel->setGeometry(QRect(180, 180, 71, 41));
        cancel->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));

        retranslateUi(evaluate);

        QMetaObject::connectSlotsByName(evaluate);
    } // setupUi

    void retranslateUi(QDialog *evaluate)
    {
        evaluate->setWindowTitle(QApplication::translate("evaluate", "Dialog", 0));
        label->setText(QApplication::translate("evaluate", "\350\257\267\346\202\250\345\257\271\346\234\254\346\254\241\350\256\242\345\215\225\350\277\233\350\241\214\350\257\204\344\273\267", 0));
        star1->setText(QString());
        star2->setText(QString());
        star3->setText(QString());
        star4->setText(QString());
        star5->setText(QString());
        confirm->setText(QApplication::translate("evaluate", "\346\217\220\344\272\244", 0));
        cancel->setText(QApplication::translate("evaluate", "\345\217\226\346\266\210", 0));
    } // retranslateUi

};

namespace Ui {
    class evaluate: public Ui_evaluate {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EVALUATE_H
