#ifndef HOTEL_H
#define HOTEL_H

#include "all_headers_nedded.h"
#include <iostream>
#include "People.h"
#include "Room.h"
using namespace std;
class Hotel : public People
{
public:
    Hotel();
    ~Hotel();
    void set_myroom(Room its_myroom[],int num);
    void set_city(QString its_city);
    void set_area(QString its_area);
    void set_hotelname(QString its_hotelname);
    void set_state(QString its_state);
    void set_star(QString its_star);
    QString get_city() const;
    QString get_area() const;
    QString get_hotelname() const;
    QString get_state() const;
    QString get_star() const;
    Room * get_myroom();
private:
    Room myroom[];
    QString city;
    QString area;
    QString hotelname;
    QString state;
    QString star;
};

#endif // HOTEL_H
