#ifndef MATCH_H
#define MATCH_H
#include "all_headers_nedded.h"
#include <iostream>
using namespace std;

class Match
{
public:
    Match();
    ~Match();
    void set_hotelname(QString its_hotelname);
    void set_manager(QString its_manager);
    QString get_hotelname() const;
    QString get_manager() const;
private:
    QString hotelname;
    QString manager;
};
#endif // MATCH_H
