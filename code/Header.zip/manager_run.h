#ifndef MANAGER_RUN_H
#define MANAGER_RUN_H

#include <QDialog>

namespace Ui {
class manager_run;
}

class manager_run : public QDialog
{
    Q_OBJECT

public:
    explicit manager_run(QWidget *parent = 0);
    ~manager_run();
    void paintEvent(QPaintEvent *event) override;
    void closeEvent(QCloseEvent * event);

private slots:
    void on_back_clicked();

    void on_look_clicked();

private:
    Ui::manager_run *ui;
};

#endif // MANAGER_RUN_H
