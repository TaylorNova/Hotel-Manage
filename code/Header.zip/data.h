#ifndef DATA_H
#define DATA_H
#include "all_headers_nedded.h"
#include "room.h"
#include "order.h"
#include "manager.h"
#include "people.h"
#include "customer.h"
#include "hotel.h"
#include "cus_record.h"
#include "match.h"
#include "evalue.h"
#include <QString>
using namespace std;


class Data
{
public:
    static vector <Customer> customers;
    static vector <Manager> managers;
    static vector <Hotel> hotels;
    static vector <Order> orders;
    static vector <Room> rooms;
    static vector <People> platform;
    static vector <Hotel> hotel_plat;
    static vector <Record> record;
    static vector <int> arr;
    static vector <Match> matchs;
    static vector <Evalue> evalues;
    static int customers_num;
    static int managers_num;
    static int hotels_num;
    static int orders_num;
    static int rooms_num;
    static int sign_num;
    static int matchs_num;
    static int evalues_num;
    static int row_check;
    static int row_check_2;
    static int row_check_3;
    static int row_check_4;
    static int row_check_5;
    static int row_check_6;
    static int hotel_plat_num;
    static int sign_num_2;
    static int sign_num_3;
    static int sign_num_4;
    static int sign_num_5;
    static int sign_num_6;
    static int sign_num_7;
    static int sign_num_8;
    static int sign_num_9;
    static int sign_num_10;
    static int sign_num_11;
    static int sign_num_12;
    static int sign_num_13;
    static int sign_num_14;
    static int sign_num_15;
    static int sign_num_16;
    static int choose_day;
    static int choose_roomnum;
    static int total_money;
    static QString file_name;
    static QString file_name_2;
    static QString current_user;
    static QString choose_hotel;
    static QString manager_hotel;
private:
    Data() = delete;
};

#endif // DATA_H
