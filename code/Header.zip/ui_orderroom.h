/********************************************************************************
** Form generated from reading UI file 'orderroom.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ORDERROOM_H
#define UI_ORDERROOM_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCalendarWidget>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>

QT_BEGIN_NAMESPACE

class Ui_orderroom
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *type;
    QLabel *price;
    QLabel *discount;
    QLabel *picture;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLineEdit *from;
    QLineEdit *to;
    QPushButton *opentime;
    QPushButton *opentime_2;
    QPushButton *confirm;
    QLabel *label_5;
    QLabel *label_9;
    QLineEdit *people;
    QLineEdit *phonenum;
    QPushButton *cancel;
    QLabel *label_10;
    QSpinBox *roomnum;
    QCalendarWidget *calendarWidget;
    QCalendarWidget *calendarWidget_2;
    QLabel *label_11;
    QLabel *lastnum;
    QLabel *label_12;
    QLabel *description;
    QLabel *tip;

    void setupUi(QDialog *orderroom)
    {
        if (orderroom->objectName().isEmpty())
            orderroom->setObjectName(QStringLiteral("orderroom"));
        orderroom->resize(590, 509);
        label = new QLabel(orderroom);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(40, 30, 71, 21));
        label->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_2 = new QLabel(orderroom);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(40, 70, 71, 21));
        label_2->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_3 = new QLabel(orderroom);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(40, 110, 71, 21));
        label_3->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_4 = new QLabel(orderroom);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(220, 30, 71, 21));
        label_4->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        type = new QLabel(orderroom);
        type->setObjectName(QStringLiteral("type"));
        type->setGeometry(QRect(110, 30, 101, 21));
        type->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        price = new QLabel(orderroom);
        price->setObjectName(QStringLiteral("price"));
        price->setGeometry(QRect(110, 70, 71, 21));
        price->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\226\271\346\255\243\345\255\227\350\277\271-\345\205\270\351\233\205\346\245\267\344\275\223\347\256\200\344\275\223\";"));
        discount = new QLabel(orderroom);
        discount->setObjectName(QStringLiteral("discount"));
        discount->setGeometry(QRect(110, 110, 71, 21));
        discount->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        picture = new QLabel(orderroom);
        picture->setObjectName(QStringLiteral("picture"));
        picture->setGeometry(QRect(300, 40, 251, 131));
        picture->setScaledContents(true);
        label_6 = new QLabel(orderroom);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(40, 230, 121, 41));
        label_6->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_7 = new QLabel(orderroom);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(170, 240, 21, 21));
        label_7->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_8 = new QLabel(orderroom);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(360, 240, 21, 21));
        label_8->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        from = new QLineEdit(orderroom);
        from->setObjectName(QStringLiteral("from"));
        from->setGeometry(QRect(210, 240, 113, 21));
        from->setStyleSheet(QStringLiteral("border:2px groove gray;border-radius:10px;padding:2px 4px"));
        to = new QLineEdit(orderroom);
        to->setObjectName(QStringLiteral("to"));
        to->setGeometry(QRect(410, 240, 113, 21));
        to->setStyleSheet(QStringLiteral("border:2px groove gray;border-radius:10px;padding:2px 4px"));
        opentime = new QPushButton(orderroom);
        opentime->setObjectName(QStringLiteral("opentime"));
        opentime->setGeometry(QRect(330, 240, 21, 21));
        opentime->setStyleSheet(QLatin1String("QPushButton\n"
"{\n"
"border-image: url(:/Image/an1.png);\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/an2.png);\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/an3.png);\n"
"}"));
        opentime_2 = new QPushButton(orderroom);
        opentime_2->setObjectName(QStringLiteral("opentime_2"));
        opentime_2->setGeometry(QRect(530, 240, 21, 21));
        opentime_2->setStyleSheet(QLatin1String("QPushButton\n"
"{\n"
"border-image: url(:/Image/an1.png);\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/an2.png);\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/an3.png);\n"
"}"));
        confirm = new QPushButton(orderroom);
        confirm->setObjectName(QStringLiteral("confirm"));
        confirm->setGeometry(QRect(110, 430, 131, 41));
        confirm->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        label_5 = new QLabel(orderroom);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(70, 340, 71, 21));
        label_5->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_9 = new QLabel(orderroom);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(70, 380, 91, 21));
        label_9->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        people = new QLineEdit(orderroom);
        people->setObjectName(QStringLiteral("people"));
        people->setGeometry(QRect(230, 340, 191, 21));
        people->setStyleSheet(QStringLiteral("border:2px groove gray;border-radius:10px;padding:2px 4px"));
        phonenum = new QLineEdit(orderroom);
        phonenum->setObjectName(QStringLiteral("phonenum"));
        phonenum->setGeometry(QRect(230, 380, 191, 21));
        phonenum->setStyleSheet(QStringLiteral("border:2px groove gray;border-radius:10px;padding:2px 4px"));
        cancel = new QPushButton(orderroom);
        cancel->setObjectName(QStringLiteral("cancel"));
        cancel->setGeometry(QRect(320, 430, 101, 41));
        cancel->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        label_10 = new QLabel(orderroom);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(70, 300, 71, 21));
        label_10->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        roomnum = new QSpinBox(orderroom);
        roomnum->setObjectName(QStringLiteral("roomnum"));
        roomnum->setGeometry(QRect(230, 300, 41, 22));
        roomnum->setStyleSheet(QLatin1String("QTimeEdit::up-button,QDoubleSpinBox::up-button,QSpinBox::up-button {subcontrol-origin:border;\n"
"    subcontrol-position:right;\n"
"    image: url(:/Image/right.png);\n"
"    width: 12px;\n"
"    height: 20px;       \n"
"}\n"
"QTimeEdit::down-button,QDoubleSpinBox::down-button,QSpinBox::down-button {subcontrol-origin:border;\n"
"    subcontrol-position:left;\n"
"    image: url(:/Image/left.png);\n"
"    width: 12px;\n"
"    height: 20px;\n"
"}\n"
"QTimeEdit::up-button:pressed,QDoubleSpinBox::up-button:pressed,QSpinBox::up-button:pressed{subcontrol-origin:border;\n"
"    subcontrol-position:right;\n"
"    image: url(:/Image/right1.png);\n"
"    width: 12px;\n"
"    height: 20px;       \n"
"}\n"
"  \n"
"QTimeEdit::down-button:pressed,QDoubleSpinBox::down-button:pressed,QSpinBox::down-button:pressed,QSpinBox::down-button:pressed{\n"
"    subcontrol-position:left;\n"
"    image: url(:/Image/left1.png);\n"
"    width: 12px;\n"
"    height: 20px;\n"
"}"));
        roomnum->setMinimum(1);
        calendarWidget = new QCalendarWidget(orderroom);
        calendarWidget->setObjectName(QStringLiteral("calendarWidget"));
        calendarWidget->setGeometry(QRect(30, 270, 296, 236));
        calendarWidget_2 = new QCalendarWidget(orderroom);
        calendarWidget_2->setObjectName(QStringLiteral("calendarWidget_2"));
        calendarWidget_2->setGeometry(QRect(270, 270, 296, 236));
        label_11 = new QLabel(orderroom);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(40, 150, 41, 21));
        label_11->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        lastnum = new QLabel(orderroom);
        lastnum->setObjectName(QStringLiteral("lastnum"));
        lastnum->setGeometry(QRect(110, 150, 71, 21));
        lastnum->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\226\271\346\255\243\345\255\227\350\277\271-\345\205\270\351\233\205\346\245\267\344\275\223\347\256\200\344\275\223\";"));
        label_12 = new QLabel(orderroom);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(40, 190, 41, 21));
        label_12->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        description = new QLabel(orderroom);
        description->setObjectName(QStringLiteral("description"));
        description->setGeometry(QRect(110, 190, 321, 21));
        description->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        tip = new QLabel(orderroom);
        tip->setObjectName(QStringLiteral("tip"));
        tip->setGeometry(QRect(460, 380, 111, 21));
        tip->setStyleSheet(QString::fromUtf8("font: 9pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        tip->raise();
        label->raise();
        label_2->raise();
        label_3->raise();
        label_4->raise();
        type->raise();
        price->raise();
        discount->raise();
        picture->raise();
        label_6->raise();
        label_7->raise();
        label_8->raise();
        from->raise();
        to->raise();
        opentime->raise();
        opentime_2->raise();
        confirm->raise();
        label_5->raise();
        label_9->raise();
        people->raise();
        phonenum->raise();
        cancel->raise();
        label_10->raise();
        roomnum->raise();
        calendarWidget->raise();
        calendarWidget_2->raise();
        label_11->raise();
        lastnum->raise();
        label_12->raise();
        description->raise();

        retranslateUi(orderroom);

        QMetaObject::connectSlotsByName(orderroom);
    } // setupUi

    void retranslateUi(QDialog *orderroom)
    {
        orderroom->setWindowTitle(QApplication::translate("orderroom", "\351\242\204\345\256\232", 0));
        label->setText(QApplication::translate("orderroom", "\346\210\277\345\236\213", 0));
        label_2->setText(QApplication::translate("orderroom", "\345\256\232\344\273\267", 0));
        label_3->setText(QApplication::translate("orderroom", "\344\274\230\346\203\240", 0));
        label_4->setText(QApplication::translate("orderroom", "\345\233\276\347\211\207", 0));
        type->setText(QApplication::translate("orderroom", "TextLabel", 0));
        price->setText(QApplication::translate("orderroom", "TextLabel", 0));
        discount->setText(QApplication::translate("orderroom", "TextLabel", 0));
        picture->setText(QApplication::translate("orderroom", "TextLabel", 0));
        label_6->setText(QApplication::translate("orderroom", "\351\200\211\346\213\251\345\205\245\344\275\217\346\227\266\351\227\264", 0));
        label_7->setText(QApplication::translate("orderroom", "\344\273\216", 0));
        label_8->setText(QApplication::translate("orderroom", "\345\210\260", 0));
        opentime->setText(QString());
        opentime_2->setText(QString());
        confirm->setText(QApplication::translate("orderroom", "\347\241\256\350\256\244\345\271\266\346\224\257\344\273\230", 0));
        label_5->setText(QApplication::translate("orderroom", "\345\205\245\344\275\217\344\272\272", 0));
        label_9->setText(QApplication::translate("orderroom", "\346\211\213\346\234\272\345\217\267\347\240\201", 0));
        cancel->setText(QApplication::translate("orderroom", "\345\217\226\346\266\210", 0));
        label_10->setText(QApplication::translate("orderroom", "\346\225\260\351\207\217", 0));
        label_11->setText(QApplication::translate("orderroom", "\344\275\231\351\207\217", 0));
        lastnum->setText(QApplication::translate("orderroom", "TextLabel", 0));
        label_12->setText(QApplication::translate("orderroom", "\346\217\217\350\277\260", 0));
        description->setText(QApplication::translate("orderroom", "TextLabel", 0));
        tip->setText(QApplication::translate("orderroom", "\346\211\213\346\234\272\345\217\267\344\270\215\350\247\204\350\214\203", 0));
    } // retranslateUi

};

namespace Ui {
    class orderroom: public Ui_orderroom {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ORDERROOM_H
