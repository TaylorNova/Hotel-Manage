#ifndef REGISTER_H
#define REGISTER_H

#include <QDialog>
#include "all_headers_nedded.h"
#include <QPaintEvent>

namespace Ui {
class Register;
}

class Register : public QDialog
{
    Q_OBJECT

public:
    explicit Register(QWidget *parent = 0);
    bool login_re_reg(const QString the_phonenum);
    ~Register();

private slots:
    void on_confirm_clicked();

protected:
    bool judge_valid_phonenum(const QString &the_phonenum);
    bool judge_blank_pwd(const QString &pwd);
    void paintEvent(QPaintEvent *event) override;

private:
    Ui::Register *ui;
};

#endif // REGISTER_H
