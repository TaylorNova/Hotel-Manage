#ifndef PLATFORM_H
#define PLATFORM_H

#include <QDialog>

namespace Ui {
class platform;
}

class platform : public QDialog
{
    Q_OBJECT

public:
    explicit platform(QWidget *parent = 0);
    ~platform();
    void paintEvent(QPaintEvent *event) override;
    void closeEvent(QCloseEvent * event);

private slots:
    void on_cancel_clicked();

    void on_pass_clicked();

    void on_sort_clicked();

    void on_cancel_2_clicked();

private:
    Ui::platform *ui;
};

#endif // PLATFORM_H
