#ifndef CHANGEROOM_H
#define CHANGEROOM_H

#include <QDialog>

namespace Ui {
class changeroom;
}

class changeroom : public QDialog
{
    Q_OBJECT

public:
    explicit changeroom(QWidget *parent = 0);
    ~changeroom();
    void paintEvent(QPaintEvent *event) override;

private slots:
    void on_cancel_clicked();

    void on_confirm_clicked();

    void on_pushButton_clicked();

private:
    Ui::changeroom *ui;
};

#endif // CHANGEROOM_H
