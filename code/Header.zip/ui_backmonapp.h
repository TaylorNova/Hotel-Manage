/********************************************************************************
** Form generated from reading UI file 'backmonapp.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BACKMONAPP_H
#define UI_BACKMONAPP_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_backmonapp
{
public:
    QLabel *label;
    QLabel *cusphonenum;
    QLabel *label_3;
    QLabel *totalmoney;
    QLabel *label_5;
    QPushButton *cancel;
    QPushButton *confirm;
    QLabel *label_2;

    void setupUi(QDialog *backmonapp)
    {
        if (backmonapp->objectName().isEmpty())
            backmonapp->setObjectName(QStringLiteral("backmonapp"));
        backmonapp->resize(338, 269);
        label = new QLabel(backmonapp);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(70, 60, 81, 31));
        label->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        cusphonenum = new QLabel(backmonapp);
        cusphonenum->setObjectName(QStringLiteral("cusphonenum"));
        cusphonenum->setGeometry(QRect(180, 60, 131, 31));
        cusphonenum->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\226\271\346\255\243\345\255\227\350\277\271-\345\205\270\351\233\205\346\245\267\344\275\223\347\256\200\344\275\223\";"));
        label_3 = new QLabel(backmonapp);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(60, 110, 91, 31));
        label_3->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        totalmoney = new QLabel(backmonapp);
        totalmoney->setObjectName(QStringLiteral("totalmoney"));
        totalmoney->setGeometry(QRect(180, 110, 81, 31));
        totalmoney->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_5 = new QLabel(backmonapp);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(130, 170, 81, 16));
        label_5->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        cancel = new QPushButton(backmonapp);
        cancel->setObjectName(QStringLiteral("cancel"));
        cancel->setGeometry(QRect(210, 210, 101, 41));
        cancel->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        confirm = new QPushButton(backmonapp);
        confirm->setObjectName(QStringLiteral("confirm"));
        confirm->setGeometry(QRect(30, 210, 91, 41));
        confirm->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        label_2 = new QLabel(backmonapp);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(260, 110, 31, 31));
        label_2->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));

        retranslateUi(backmonapp);

        QMetaObject::connectSlotsByName(backmonapp);
    } // setupUi

    void retranslateUi(QDialog *backmonapp)
    {
        backmonapp->setWindowTitle(QApplication::translate("backmonapp", "\351\200\200\346\254\276\347\224\263\350\257\267", 0));
        label->setText(QApplication::translate("backmonapp", "\351\200\200\346\254\276\344\272\272", 0));
        cusphonenum->setText(QApplication::translate("backmonapp", "TextLabel", 0));
        label_3->setText(QApplication::translate("backmonapp", "\351\200\200\346\254\276\351\207\221\351\242\235", 0));
        totalmoney->setText(QApplication::translate("backmonapp", "TextLabel", 0));
        label_5->setText(QApplication::translate("backmonapp", "\347\241\256\350\256\244\351\200\200\346\254\276\357\274\237", 0));
        cancel->setText(QApplication::translate("backmonapp", "\345\217\226\346\266\210", 0));
        confirm->setText(QApplication::translate("backmonapp", "\347\241\256\350\256\244", 0));
        label_2->setText(QApplication::translate("backmonapp", "\345\205\203", 0));
    } // retranslateUi

};

namespace Ui {
    class backmonapp: public Ui_backmonapp {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BACKMONAPP_H
