/********************************************************************************
** Form generated from reading UI file 'backmoncheck.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BACKMONCHECK_H
#define UI_BACKMONCHECK_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_backmoncheck
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *cusphonenum;
    QLabel *totalmoney;
    QLabel *label_5;
    QPushButton *confirm;
    QPushButton *cancel;
    QLabel *label_3;

    void setupUi(QDialog *backmoncheck)
    {
        if (backmoncheck->objectName().isEmpty())
            backmoncheck->setObjectName(QStringLiteral("backmoncheck"));
        backmoncheck->resize(394, 288);
        label = new QLabel(backmoncheck);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(80, 60, 81, 31));
        label->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_2 = new QLabel(backmoncheck);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(80, 120, 81, 31));
        label_2->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        cusphonenum = new QLabel(backmoncheck);
        cusphonenum->setObjectName(QStringLiteral("cusphonenum"));
        cusphonenum->setGeometry(QRect(220, 60, 111, 31));
        cusphonenum->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\226\271\346\255\243\345\255\227\350\277\271-\345\205\270\351\233\205\346\245\267\344\275\223\347\256\200\344\275\223\";"));
        totalmoney = new QLabel(backmoncheck);
        totalmoney->setObjectName(QStringLiteral("totalmoney"));
        totalmoney->setGeometry(QRect(220, 120, 71, 31));
        totalmoney->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_5 = new QLabel(backmoncheck);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(150, 180, 191, 16));
        label_5->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        confirm = new QPushButton(backmoncheck);
        confirm->setObjectName(QStringLiteral("confirm"));
        confirm->setGeometry(QRect(50, 220, 101, 41));
        confirm->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        cancel = new QPushButton(backmoncheck);
        cancel->setObjectName(QStringLiteral("cancel"));
        cancel->setGeometry(QRect(250, 220, 101, 41));
        cancel->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        label_3 = new QLabel(backmoncheck);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(300, 120, 21, 31));
        label_3->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));

        retranslateUi(backmoncheck);

        QMetaObject::connectSlotsByName(backmoncheck);
    } // setupUi

    void retranslateUi(QDialog *backmoncheck)
    {
        backmoncheck->setWindowTitle(QApplication::translate("backmoncheck", "\351\200\200\346\254\276\345\217\227\347\220\206", 0));
        label->setText(QApplication::translate("backmoncheck", "\351\200\200\346\254\276\347\224\250\346\210\267", 0));
        label_2->setText(QApplication::translate("backmoncheck", "\351\200\200\346\254\276\351\207\221\351\242\235", 0));
        cusphonenum->setText(QApplication::translate("backmoncheck", "TextLabel", 0));
        totalmoney->setText(QApplication::translate("backmoncheck", "TextLabel", 0));
        label_5->setText(QApplication::translate("backmoncheck", "\347\241\256\350\256\244\345\217\227\347\220\206\351\200\200\346\254\276?", 0));
        confirm->setText(QApplication::translate("backmoncheck", "\347\241\256\350\256\244", 0));
        cancel->setText(QApplication::translate("backmoncheck", "\345\217\226\346\266\210", 0));
        label_3->setText(QApplication::translate("backmoncheck", "\345\205\203", 0));
    } // retranslateUi

};

namespace Ui {
    class backmoncheck: public Ui_backmoncheck {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BACKMONCHECK_H
