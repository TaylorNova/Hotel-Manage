#ifndef SETSTARLEVEL_H
#define SETSTARLEVEL_H

#include <QDialog>

namespace Ui {
class setstarlevel;
}

class setstarlevel : public QDialog
{
    Q_OBJECT

public:
    explicit setstarlevel(QWidget *parent = 0);
    ~setstarlevel();

private slots:
    void on_cancel_clicked();

    void on_confirm_clicked();

private:
    Ui::setstarlevel *ui;
};

#endif // SETSTARLEVEL_H
