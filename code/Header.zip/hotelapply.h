#ifndef HOTELAPPLY_H
#define HOTELAPPLY_H

#include <QDialog>

namespace Ui {
class hotelapply;
}

class hotelapply : public QDialog
{
    Q_OBJECT

public:
    explicit hotelapply(QWidget *parent = 0);
    ~hotelapply();
    void paintEvent(QPaintEvent *event) override;

private slots:
    void on_cancel_clicked();

    void on_apply_clicked();

private:
    Ui::hotelapply *ui;
};

#endif // HOTELAPPLY_H
