/********************************************************************************
** Form generated from reading UI file 'managecheck.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MANAGECHECK_H
#define UI_MANAGECHECK_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_managecheck
{
public:
    QPushButton *back;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *cusphonenum;
    QLabel *roomtype;
    QLabel *price;
    QLabel *roomnum;
    QLabel *fromtime;
    QLabel *totime;
    QLabel *totalmoney;
    QLabel *picture;
    QLabel *paystate;
    QLabel *backmonstate;
    QLabel *staystate;
    QPushButton *bamoncon;
    QComboBox *comboBox;
    QPushButton *constaystate;
    QLabel *label_14;

    void setupUi(QDialog *managecheck)
    {
        if (managecheck->objectName().isEmpty())
            managecheck->setObjectName(QStringLiteral("managecheck"));
        managecheck->resize(548, 446);
        back = new QPushButton(managecheck);
        back->setObjectName(QStringLiteral("back"));
        back->setGeometry(QRect(220, 400, 101, 41));
        back->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/ku1.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(213, 108, 15)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/ku2.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(244, 234, 41)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/ku3.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(153, 94, 30)\n"
"}"));
        label = new QLabel(managecheck);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(50, 40, 71, 21));
        label->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_2 = new QLabel(managecheck);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(50, 70, 71, 21));
        label_2->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_3 = new QLabel(managecheck);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(50, 100, 71, 21));
        label_3->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_4 = new QLabel(managecheck);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(270, 40, 71, 21));
        label_4->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_5 = new QLabel(managecheck);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(20, 0, 161, 31));
        label_5->setStyleSheet(QString::fromUtf8("font: 25 14pt \"\346\226\271\346\255\243\347\273\217\351\273\221\347\256\200\344\275\223\";"));
        label_6 = new QLabel(managecheck);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(50, 130, 71, 21));
        label_6->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_7 = new QLabel(managecheck);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(50, 180, 71, 31));
        label_7->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_8 = new QLabel(managecheck);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(250, 190, 16, 16));
        label_8->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_9 = new QLabel(managecheck);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(50, 220, 91, 21));
        label_9->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_10 = new QLabel(managecheck);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(20, 250, 111, 31));
        label_10->setStyleSheet(QString::fromUtf8("font: 25 14pt \"\346\226\271\346\255\243\347\273\217\351\273\221\347\256\200\344\275\223\";"));
        label_11 = new QLabel(managecheck);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(90, 280, 81, 21));
        label_11->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_12 = new QLabel(managecheck);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(90, 320, 81, 21));
        label_12->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_13 = new QLabel(managecheck);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(90, 360, 81, 21));
        label_13->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        cusphonenum = new QLabel(managecheck);
        cusphonenum->setObjectName(QStringLiteral("cusphonenum"));
        cusphonenum->setGeometry(QRect(120, 40, 101, 21));
        cusphonenum->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        roomtype = new QLabel(managecheck);
        roomtype->setObjectName(QStringLiteral("roomtype"));
        roomtype->setGeometry(QRect(120, 70, 101, 21));
        roomtype->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        price = new QLabel(managecheck);
        price->setObjectName(QStringLiteral("price"));
        price->setGeometry(QRect(120, 100, 71, 21));
        price->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\226\271\346\255\243\345\255\227\350\277\271-\345\205\270\351\233\205\346\245\267\344\275\223\347\256\200\344\275\223\";"));
        roomnum = new QLabel(managecheck);
        roomnum->setObjectName(QStringLiteral("roomnum"));
        roomnum->setGeometry(QRect(120, 130, 71, 21));
        roomnum->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\226\271\346\255\243\345\255\227\350\277\271-\345\205\270\351\233\205\346\245\267\344\275\223\347\256\200\344\275\223\";"));
        fromtime = new QLabel(managecheck);
        fromtime->setObjectName(QStringLiteral("fromtime"));
        fromtime->setGeometry(QRect(130, 180, 101, 31));
        fromtime->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\226\271\346\255\243\345\255\227\350\277\271-\345\205\270\351\233\205\346\245\267\344\275\223\347\256\200\344\275\223\";"));
        totime = new QLabel(managecheck);
        totime->setObjectName(QStringLiteral("totime"));
        totime->setGeometry(QRect(310, 180, 101, 31));
        totime->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\226\271\346\255\243\345\255\227\350\277\271-\345\205\270\351\233\205\346\245\267\344\275\223\347\256\200\344\275\223\";"));
        totalmoney = new QLabel(managecheck);
        totalmoney->setObjectName(QStringLiteral("totalmoney"));
        totalmoney->setGeometry(QRect(160, 220, 72, 15));
        totalmoney->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\226\271\346\255\243\345\255\227\350\277\271-\345\205\270\351\233\205\346\245\267\344\275\223\347\256\200\344\275\223\";"));
        picture = new QLabel(managecheck);
        picture->setObjectName(QStringLiteral("picture"));
        picture->setGeometry(QRect(280, 60, 211, 111));
        picture->setScaledContents(true);
        paystate = new QLabel(managecheck);
        paystate->setObjectName(QStringLiteral("paystate"));
        paystate->setGeometry(QRect(220, 280, 71, 21));
        paystate->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        backmonstate = new QLabel(managecheck);
        backmonstate->setObjectName(QStringLiteral("backmonstate"));
        backmonstate->setGeometry(QRect(220, 320, 101, 21));
        backmonstate->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        staystate = new QLabel(managecheck);
        staystate->setObjectName(QStringLiteral("staystate"));
        staystate->setGeometry(QRect(220, 360, 71, 21));
        staystate->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        bamoncon = new QPushButton(managecheck);
        bamoncon->setObjectName(QStringLiteral("bamoncon"));
        bamoncon->setGeometry(QRect(330, 310, 91, 41));
        bamoncon->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/ku4.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(213, 108, 15)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/ku5.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(244, 234, 41)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/ku6.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(153, 94, 30)\n"
"}"));
        comboBox = new QComboBox(managecheck);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(330, 350, 87, 31));
        constaystate = new QPushButton(managecheck);
        constaystate->setObjectName(QStringLiteral("constaystate"));
        constaystate->setGeometry(QRect(480, 350, 51, 31));
        constaystate->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/ku1.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(213, 108, 15)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/ku2.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(244, 234, 41)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/ku3.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(153, 94, 30)\n"
"}"));
        label_14 = new QLabel(managecheck);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(250, 220, 21, 16));
        label_14->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));

        retranslateUi(managecheck);

        QMetaObject::connectSlotsByName(managecheck);
    } // setupUi

    void retranslateUi(QDialog *managecheck)
    {
        managecheck->setWindowTitle(QApplication::translate("managecheck", "\346\237\245\347\234\213\350\256\242\345\215\225\350\257\246\346\203\205", 0));
        back->setText(QApplication::translate("managecheck", "\350\277\224\345\233\236", 0));
        label->setText(QApplication::translate("managecheck", "\347\224\250\346\210\267", 0));
        label_2->setText(QApplication::translate("managecheck", "\346\210\277\345\236\213", 0));
        label_3->setText(QApplication::translate("managecheck", "\345\215\225\344\273\267", 0));
        label_4->setText(QApplication::translate("managecheck", "\345\233\276\347\211\207", 0));
        label_5->setText(QApplication::translate("managecheck", "\350\256\242\345\215\225\345\237\272\346\234\254\344\277\241\346\201\257", 0));
        label_6->setText(QApplication::translate("managecheck", "\346\225\260\351\207\217", 0));
        label_7->setText(QApplication::translate("managecheck", "\351\242\204\345\256\232\344\273\216", 0));
        label_8->setText(QApplication::translate("managecheck", "\345\210\260", 0));
        label_9->setText(QApplication::translate("managecheck", "\350\256\242\345\215\225\346\200\273\351\207\221\351\242\235", 0));
        label_10->setText(QApplication::translate("managecheck", "\350\256\242\345\215\225\347\212\266\346\200\201", 0));
        label_11->setText(QApplication::translate("managecheck", "\346\224\257\344\273\230\347\212\266\346\200\201", 0));
        label_12->setText(QApplication::translate("managecheck", "\351\200\200\346\254\276\347\212\266\346\200\201", 0));
        label_13->setText(QApplication::translate("managecheck", "\345\205\245\344\275\217\347\212\266\346\200\201", 0));
        cusphonenum->setText(QApplication::translate("managecheck", "TextLabel", 0));
        roomtype->setText(QApplication::translate("managecheck", "TextLabel", 0));
        price->setText(QApplication::translate("managecheck", "TextLabel", 0));
        roomnum->setText(QApplication::translate("managecheck", "TextLabel", 0));
        fromtime->setText(QApplication::translate("managecheck", "TextLabel", 0));
        totime->setText(QApplication::translate("managecheck", "TextLabel", 0));
        totalmoney->setText(QApplication::translate("managecheck", "TextLabel", 0));
        picture->setText(QApplication::translate("managecheck", "TextLabel", 0));
        paystate->setText(QApplication::translate("managecheck", "TextLabel", 0));
        backmonstate->setText(QApplication::translate("managecheck", "TextLabel", 0));
        staystate->setText(QApplication::translate("managecheck", "TextLabel", 0));
        bamoncon->setText(QApplication::translate("managecheck", "\351\200\200\346\254\276\345\217\227\347\220\206", 0));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("managecheck", "\346\234\252\345\205\245\344\275\217", 0)
         << QApplication::translate("managecheck", "\345\267\262\345\205\245\344\275\217", 0)
         << QApplication::translate("managecheck", "\345\267\262\351\200\200\346\210\277", 0)
        );
        constaystate->setText(QApplication::translate("managecheck", "\347\241\256\350\256\244", 0));
        label_14->setText(QApplication::translate("managecheck", "\345\205\203", 0));
    } // retranslateUi

};

namespace Ui {
    class managecheck: public Ui_managecheck {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MANAGECHECK_H
