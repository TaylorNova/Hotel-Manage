#ifndef EVALUATE_H
#define EVALUATE_H

#include <QDialog>

namespace Ui {
class evaluate;
}

class evaluate : public QDialog
{
    Q_OBJECT

public:
    explicit evaluate(QWidget *parent = 0);
    ~evaluate();

private slots:
    void on_cancel_clicked();

    void on_star1_clicked();

    void on_star2_clicked();

    void on_star3_clicked();

    void on_star4_clicked();

    void on_star5_clicked();

    void on_confirm_clicked();

private:
    Ui::evaluate *ui;
};

#endif // EVALUATE_H
