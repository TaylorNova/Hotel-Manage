#ifndef ORDERROOM_H
#define ORDERROOM_H

#include <QDialog>

namespace Ui {
class orderroom;
}

class orderroom : public QDialog
{
    Q_OBJECT

public:
    explicit orderroom(QWidget *parent = 0);
    ~orderroom();
    bool judge_valid_phonenum(QString the_phonenum);
    void paintEvent(QPaintEvent *event) override;

private slots:
    void on_opentime_clicked();

    void on_opentime_2_clicked();

    void on_cancel_clicked();

    void on_confirm_clicked();

public slots:
    void settime_1();
    void settime_2();

private:
    Ui::orderroom *ui;
};

#endif // ORDERROOM_H
