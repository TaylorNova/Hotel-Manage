/********************************************************************************
** Form generated from reading UI file 'seeroom.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEEROOM_H
#define UI_SEEROOM_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>

QT_BEGIN_NAMESPACE

class Ui_seeroom
{
public:
    QTableWidget *view;
    QPushButton *cancel;
    QPushButton *sort_down;
    QPushButton *sort_up;
    QPushButton *order;

    void setupUi(QDialog *seeroom)
    {
        if (seeroom->objectName().isEmpty())
            seeroom->setObjectName(QStringLiteral("seeroom"));
        seeroom->resize(684, 483);
        view = new QTableWidget(seeroom);
        if (view->columnCount() < 5)
            view->setColumnCount(5);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        view->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        view->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        view->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        view->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        view->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        view->setObjectName(QStringLiteral("view"));
        view->setGeometry(QRect(20, 10, 641, 301));
        view->setShowGrid(false);
        cancel = new QPushButton(seeroom);
        cancel->setObjectName(QStringLiteral("cancel"));
        cancel->setGeometry(QRect(440, 410, 111, 41));
        cancel->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        sort_down = new QPushButton(seeroom);
        sort_down->setObjectName(QStringLiteral("sort_down"));
        sort_down->setGeometry(QRect(120, 350, 151, 41));
        sort_down->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang18.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kaung14.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang17.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        sort_up = new QPushButton(seeroom);
        sort_up->setObjectName(QStringLiteral("sort_up"));
        sort_up->setGeometry(QRect(120, 410, 151, 41));
        sort_up->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang18.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kaung14.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang17.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        order = new QPushButton(seeroom);
        order->setObjectName(QStringLiteral("order"));
        order->setGeometry(QRect(440, 350, 111, 41));
        order->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));

        retranslateUi(seeroom);

        QMetaObject::connectSlotsByName(seeroom);
    } // setupUi

    void retranslateUi(QDialog *seeroom)
    {
        seeroom->setWindowTitle(QApplication::translate("seeroom", "\351\205\222\345\272\227\345\256\242\346\210\277", 0));
        QTableWidgetItem *___qtablewidgetitem = view->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("seeroom", "\346\210\277\345\236\213", 0));
        QTableWidgetItem *___qtablewidgetitem1 = view->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("seeroom", "\345\256\232\344\273\267", 0));
        QTableWidgetItem *___qtablewidgetitem2 = view->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("seeroom", "\345\211\251\344\275\231\346\225\260\351\207\217", 0));
        QTableWidgetItem *___qtablewidgetitem3 = view->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("seeroom", "\345\233\276\347\211\207", 0));
        QTableWidgetItem *___qtablewidgetitem4 = view->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("seeroom", "\351\200\211\346\213\251", 0));
        cancel->setText(QApplication::translate("seeroom", "\345\217\226\346\266\210", 0));
        sort_down->setText(QApplication::translate("seeroom", "\346\214\211\344\273\267\346\240\274\345\215\207\345\272\217\346\216\222\345\272\217", 0));
        sort_up->setText(QApplication::translate("seeroom", "\346\214\211\344\273\267\346\240\274\351\231\215\345\272\217\346\216\222\345\272\217", 0));
        order->setText(QApplication::translate("seeroom", "\351\242\204\345\256\232", 0));
    } // retranslateUi

};

namespace Ui {
    class seeroom: public Ui_seeroom {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEEROOM_H
