#ifndef MANAGER_H
#define MANAGER_H

#include "all_headers_nedded.h"
#include <iostream>
#include "People.h"
#include "Order.h"
using namespace std;

class Manager :public People
{
public:
    Manager();
    ~Manager();
    void set_order(Order its_ord[],int num);
    Order * get_order();
private:
    Order order[];
};

#endif // MANAGER_H
