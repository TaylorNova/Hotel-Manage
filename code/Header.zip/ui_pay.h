/********************************************************************************
** Form generated from reading UI file 'pay.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PAY_H
#define UI_PAY_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_pay
{
public:
    QPushButton *confirm;
    QPushButton *cancel;
    QLabel *label;
    QLabel *price;
    QLabel *label_2;

    void setupUi(QDialog *pay)
    {
        if (pay->objectName().isEmpty())
            pay->setObjectName(QStringLiteral("pay"));
        pay->resize(359, 149);
        confirm = new QPushButton(pay);
        confirm->setObjectName(QStringLiteral("confirm"));
        confirm->setGeometry(QRect(40, 90, 101, 41));
        confirm->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        cancel = new QPushButton(pay);
        cancel->setObjectName(QStringLiteral("cancel"));
        cancel->setGeometry(QRect(210, 90, 101, 41));
        cancel->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        label = new QLabel(pay);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(60, 30, 111, 31));
        label->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        price = new QLabel(pay);
        price->setObjectName(QStringLiteral("price"));
        price->setGeometry(QRect(190, 30, 81, 31));
        price->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\226\271\346\255\243\345\255\227\350\277\271-\345\205\270\351\233\205\346\245\267\344\275\223\347\256\200\344\275\223\";"));
        label_2 = new QLabel(pay);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(280, 30, 72, 31));
        label_2->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));

        retranslateUi(pay);

        QMetaObject::connectSlotsByName(pay);
    } // setupUi

    void retranslateUi(QDialog *pay)
    {
        pay->setWindowTitle(QApplication::translate("pay", "\346\224\257\344\273\230", 0));
        confirm->setText(QApplication::translate("pay", "\347\241\256\350\256\244\346\224\257\344\273\230", 0));
        cancel->setText(QApplication::translate("pay", "\345\217\226\346\266\210", 0));
        label->setText(QApplication::translate("pay", "\344\275\240\351\234\200\350\246\201\346\224\257\344\273\230", 0));
        price->setText(QApplication::translate("pay", "TextLabel", 0));
        label_2->setText(QApplication::translate("pay", "\345\205\203", 0));
    } // retranslateUi

};

namespace Ui {
    class pay: public Ui_pay {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PAY_H
