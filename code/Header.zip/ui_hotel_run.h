/********************************************************************************
** Form generated from reading UI file 'hotel_run.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HOTEL_RUN_H
#define UI_HOTEL_RUN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>

QT_BEGIN_NAMESPACE

class Ui_hotel_run
{
public:
    QPushButton *back;
    QTableWidget *tableWidget;
    QPushButton *add;
    QPushButton *change;
    QLabel *label;

    void setupUi(QDialog *hotel_run)
    {
        if (hotel_run->objectName().isEmpty())
            hotel_run->setObjectName(QStringLiteral("hotel_run"));
        hotel_run->resize(627, 523);
        back = new QPushButton(hotel_run);
        back->setObjectName(QStringLiteral("back"));
        back->setGeometry(QRect(260, 440, 101, 41));
        back->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        tableWidget = new QTableWidget(hotel_run);
        if (tableWidget->columnCount() < 4)
            tableWidget->setColumnCount(4);
        QIcon icon;
        QString iconThemeName = QString::fromUtf8("\345\256\242\346\210\277\347\256\241\347\220\206");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon = QIcon::fromTheme(iconThemeName);
        } else {
            icon.addFile(QStringLiteral("."), QSize(), QIcon::Normal, QIcon::Off);
        }
        QFont font;
        font.setFamily(QString::fromUtf8("\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223"));
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        __qtablewidgetitem->setFont(font);
        __qtablewidgetitem->setIcon(icon);
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        __qtablewidgetitem1->setFont(font);
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        __qtablewidgetitem2->setFont(font);
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        __qtablewidgetitem3->setFont(font);
        tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        tableWidget->setObjectName(QStringLiteral("tableWidget"));
        tableWidget->setGeometry(QRect(50, 60, 541, 301));
        tableWidget->setShowGrid(false);
        tableWidget->setCornerButtonEnabled(true);
        add = new QPushButton(hotel_run);
        add->setObjectName(QStringLiteral("add"));
        add->setGeometry(QRect(100, 380, 101, 41));
        add->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        change = new QPushButton(hotel_run);
        change->setObjectName(QStringLiteral("change"));
        change->setGeometry(QRect(430, 380, 101, 41));
        change->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        label = new QLabel(hotel_run);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(60, 10, 111, 41));
        label->setStyleSheet(QString::fromUtf8("font: 25 14pt \"\346\226\271\346\255\243\347\273\217\351\273\221\347\256\200\344\275\223\";"));

        retranslateUi(hotel_run);

        QMetaObject::connectSlotsByName(hotel_run);
    } // setupUi

    void retranslateUi(QDialog *hotel_run)
    {
        hotel_run->setWindowTitle(QApplication::translate("hotel_run", "\351\205\222\345\272\227", 0));
        back->setText(QApplication::translate("hotel_run", "\350\277\224\345\233\236", 0));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("hotel_run", "\347\261\273\345\236\213", 0));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("hotel_run", "\344\273\267\346\240\274", 0));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("hotel_run", "\344\275\231\351\207\217", 0));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("hotel_run", "\351\200\211\346\213\251", 0));
        add->setText(QApplication::translate("hotel_run", "\346\267\273\345\212\240", 0));
        change->setText(QApplication::translate("hotel_run", "\344\277\256\346\224\271", 0));
        label->setText(QApplication::translate("hotel_run", "\347\256\241\347\220\206\345\256\242\346\210\277", 0));
    } // retranslateUi

};

namespace Ui {
    class hotel_run: public Ui_hotel_run {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HOTEL_RUN_H
