/********************************************************************************
** Form generated from reading UI file 'checkorder.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHECKORDER_H
#define UI_CHECKORDER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_checkorder
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *type;
    QLabel *price;
    QLabel *discount;
    QLabel *roomnum;
    QLabel *fromtime;
    QLabel *totime;
    QLabel *totalmoney;
    QLabel *paystate;
    QLabel *backmonstate;
    QLabel *staystate;
    QPushButton *back;
    QLabel *picture;
    QLabel *label_14;
    QLabel *label_15;
    QPushButton *backmonapply;
    QPushButton *evaluate;

    void setupUi(QDialog *checkorder)
    {
        if (checkorder->objectName().isEmpty())
            checkorder->setObjectName(QStringLiteral("checkorder"));
        checkorder->resize(588, 495);
        label = new QLabel(checkorder);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(60, 40, 71, 21));
        label->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_2 = new QLabel(checkorder);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(60, 80, 71, 21));
        label_2->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_3 = new QLabel(checkorder);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(60, 120, 71, 21));
        label_3->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_4 = new QLabel(checkorder);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(270, 40, 71, 21));
        label_4->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_5 = new QLabel(checkorder);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(50, 170, 131, 16));
        label_5->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_6 = new QLabel(checkorder);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(350, 210, 21, 16));
        label_6->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_7 = new QLabel(checkorder);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(50, 210, 181, 16));
        label_7->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_8 = new QLabel(checkorder);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(50, 250, 121, 16));
        label_8->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_9 = new QLabel(checkorder);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(10, 0, 161, 31));
        label_9->setStyleSheet(QString::fromUtf8("font: 25 14pt \"\346\226\271\346\255\243\347\273\217\351\273\221\347\256\200\344\275\223\";"));
        label_10 = new QLabel(checkorder);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(10, 270, 101, 51));
        label_10->setStyleSheet(QString::fromUtf8("font: 25 14pt \"\346\226\271\346\255\243\347\273\217\351\273\221\347\256\200\344\275\223\";"));
        label_11 = new QLabel(checkorder);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(180, 310, 71, 21));
        label_11->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_12 = new QLabel(checkorder);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(180, 350, 71, 21));
        label_12->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_13 = new QLabel(checkorder);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(180, 390, 71, 21));
        label_13->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        type = new QLabel(checkorder);
        type->setObjectName(QStringLiteral("type"));
        type->setGeometry(QRect(150, 30, 101, 41));
        type->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        price = new QLabel(checkorder);
        price->setObjectName(QStringLiteral("price"));
        price->setGeometry(QRect(150, 80, 81, 21));
        price->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        discount = new QLabel(checkorder);
        discount->setObjectName(QStringLiteral("discount"));
        discount->setGeometry(QRect(150, 120, 81, 21));
        discount->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        roomnum = new QLabel(checkorder);
        roomnum->setObjectName(QStringLiteral("roomnum"));
        roomnum->setGeometry(QRect(210, 170, 72, 15));
        roomnum->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\226\271\346\255\243\345\255\227\350\277\271-\345\205\270\351\233\205\346\245\267\344\275\223\347\256\200\344\275\223\";"));
        fromtime = new QLabel(checkorder);
        fromtime->setObjectName(QStringLiteral("fromtime"));
        fromtime->setGeometry(QRect(220, 210, 101, 16));
        fromtime->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\226\271\346\255\243\345\255\227\350\277\271-\345\205\270\351\233\205\346\245\267\344\275\223\347\256\200\344\275\223\";"));
        totime = new QLabel(checkorder);
        totime->setObjectName(QStringLiteral("totime"));
        totime->setGeometry(QRect(430, 210, 101, 16));
        totime->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\226\271\346\255\243\345\255\227\350\277\271-\345\205\270\351\233\205\346\245\267\344\275\223\347\256\200\344\275\223\";"));
        totalmoney = new QLabel(checkorder);
        totalmoney->setObjectName(QStringLiteral("totalmoney"));
        totalmoney->setGeometry(QRect(200, 250, 72, 15));
        totalmoney->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\226\271\346\255\243\345\255\227\350\277\271-\345\205\270\351\233\205\346\245\267\344\275\223\347\256\200\344\275\223\";"));
        paystate = new QLabel(checkorder);
        paystate->setObjectName(QStringLiteral("paystate"));
        paystate->setGeometry(QRect(310, 310, 72, 15));
        paystate->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        backmonstate = new QLabel(checkorder);
        backmonstate->setObjectName(QStringLiteral("backmonstate"));
        backmonstate->setGeometry(QRect(310, 350, 111, 16));
        backmonstate->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        staystate = new QLabel(checkorder);
        staystate->setObjectName(QStringLiteral("staystate"));
        staystate->setGeometry(QRect(310, 390, 72, 15));
        staystate->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        back = new QPushButton(checkorder);
        back->setObjectName(QStringLiteral("back"));
        back->setGeometry(QRect(240, 430, 111, 51));
        back->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/ku1.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(213, 108, 15)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/ku2.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(244, 234, 41)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/ku3.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(153, 94, 30)\n"
"}"));
        picture = new QLabel(checkorder);
        picture->setObjectName(QStringLiteral("picture"));
        picture->setGeometry(QRect(330, 30, 221, 121));
        picture->setScaledContents(true);
        label_14 = new QLabel(checkorder);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(270, 250, 16, 16));
        label_14->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_15 = new QLabel(checkorder);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(280, 170, 21, 16));
        label_15->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        backmonapply = new QPushButton(checkorder);
        backmonapply->setObjectName(QStringLiteral("backmonapply"));
        backmonapply->setGeometry(QRect(420, 330, 101, 51));
        backmonapply->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/ku4.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(213, 108, 15)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/ku5.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(244, 234, 41)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/ku6.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(153, 94, 30)\n"
"}"));
        evaluate = new QPushButton(checkorder);
        evaluate->setObjectName(QStringLiteral("evaluate"));
        evaluate->setGeometry(QRect(30, 430, 111, 51));
        evaluate->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/ku1.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(213, 108, 15)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/ku2.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(244, 234, 41)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/ku3.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(153, 94, 30)\n"
"}"));

        retranslateUi(checkorder);

        QMetaObject::connectSlotsByName(checkorder);
    } // setupUi

    void retranslateUi(QDialog *checkorder)
    {
        checkorder->setWindowTitle(QApplication::translate("checkorder", "\346\237\245\347\234\213\350\256\242\345\215\225\350\257\246\346\203\205", 0));
        label->setText(QApplication::translate("checkorder", "\346\210\277\345\236\213", 0));
        label_2->setText(QApplication::translate("checkorder", "\345\215\225\344\273\267", 0));
        label_3->setText(QApplication::translate("checkorder", "\344\274\230\346\203\240", 0));
        label_4->setText(QApplication::translate("checkorder", "\345\233\276\347\211\207", 0));
        label_5->setText(QApplication::translate("checkorder", "\346\202\250\351\242\204\345\256\232\347\232\204\346\210\277\351\227\264\346\225\260", 0));
        label_6->setText(QApplication::translate("checkorder", "\345\210\260", 0));
        label_7->setText(QApplication::translate("checkorder", "\346\202\250\351\242\204\345\256\232\347\232\204\346\210\277\351\227\264\346\230\257\344\273\216", 0));
        label_8->setText(QApplication::translate("checkorder", "\350\256\242\345\215\225\346\200\273\351\207\221\351\242\235", 0));
        label_9->setText(QApplication::translate("checkorder", "\350\256\242\345\215\225\345\237\272\346\234\254\344\277\241\346\201\257", 0));
        label_10->setText(QApplication::translate("checkorder", "\350\256\242\345\215\225\347\212\266\346\200\201", 0));
        label_11->setText(QApplication::translate("checkorder", "\346\224\257\344\273\230\347\212\266\346\200\201", 0));
        label_12->setText(QApplication::translate("checkorder", "\351\200\200\346\254\276\347\212\266\346\200\201", 0));
        label_13->setText(QApplication::translate("checkorder", "\345\261\205\344\275\217\347\212\266\346\200\201", 0));
        type->setText(QApplication::translate("checkorder", "TextLabel", 0));
        price->setText(QApplication::translate("checkorder", "TextLabel", 0));
        discount->setText(QApplication::translate("checkorder", "TextLabel", 0));
        roomnum->setText(QApplication::translate("checkorder", "TextLabel", 0));
        fromtime->setText(QApplication::translate("checkorder", "TextLabel", 0));
        totime->setText(QApplication::translate("checkorder", "TextLabel", 0));
        totalmoney->setText(QApplication::translate("checkorder", "TextLabel", 0));
        paystate->setText(QApplication::translate("checkorder", "TextLabel", 0));
        backmonstate->setText(QApplication::translate("checkorder", "TextLabel", 0));
        staystate->setText(QApplication::translate("checkorder", "TextLabel", 0));
        back->setText(QApplication::translate("checkorder", "\350\277\224\345\233\236", 0));
        picture->setText(QApplication::translate("checkorder", "TextLabel", 0));
        label_14->setText(QApplication::translate("checkorder", "\345\205\203", 0));
        label_15->setText(QApplication::translate("checkorder", "\351\227\264", 0));
        backmonapply->setText(QApplication::translate("checkorder", "\347\224\263\350\257\267\351\200\200\346\254\276", 0));
        evaluate->setText(QApplication::translate("checkorder", "\350\257\204\344\273\267", 0));
    } // retranslateUi

};

namespace Ui {
    class checkorder: public Ui_checkorder {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHECKORDER_H
