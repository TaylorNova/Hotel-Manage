/********************************************************************************
** Form generated from reading UI file 'hotelapply.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HOTELAPPLY_H
#define UI_HOTELAPPLY_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_hotelapply
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *hotelname;
    QPushButton *apply;
    QPushButton *cancel;
    QComboBox *city;
    QComboBox *area;

    void setupUi(QDialog *hotelapply)
    {
        if (hotelapply->objectName().isEmpty())
            hotelapply->setObjectName(QStringLiteral("hotelapply"));
        hotelapply->resize(465, 428);
        label = new QLabel(hotelapply);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(70, 50, 71, 21));
        label->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_2 = new QLabel(hotelapply);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(70, 120, 71, 21));
        label_2->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_3 = new QLabel(hotelapply);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(70, 190, 71, 21));
        label_3->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        hotelname = new QLineEdit(hotelapply);
        hotelname->setObjectName(QStringLiteral("hotelname"));
        hotelname->setGeometry(QRect(210, 50, 131, 21));
        hotelname->setStyleSheet(QStringLiteral("border:2px groove gray;border-radius:10px;padding:2px 4px"));
        apply = new QPushButton(hotelapply);
        apply->setObjectName(QStringLiteral("apply"));
        apply->setGeometry(QRect(90, 300, 101, 41));
        apply->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        cancel = new QPushButton(hotelapply);
        cancel->setObjectName(QStringLiteral("cancel"));
        cancel->setGeometry(QRect(270, 300, 101, 41));
        cancel->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang8.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(96, 14, 89)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang9.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(148, 17, 137)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang10.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(86, 11, 80)\n"
"}"));
        city = new QComboBox(hotelapply);
        city->setObjectName(QStringLiteral("city"));
        city->setGeometry(QRect(210, 120, 101, 22));
        area = new QComboBox(hotelapply);
        area->setObjectName(QStringLiteral("area"));
        area->setGeometry(QRect(210, 190, 101, 22));

        retranslateUi(hotelapply);

        QMetaObject::connectSlotsByName(hotelapply);
    } // setupUi

    void retranslateUi(QDialog *hotelapply)
    {
        hotelapply->setWindowTitle(QApplication::translate("hotelapply", "\351\205\222\345\272\227\347\224\263\350\257\267", 0));
        label->setText(QApplication::translate("hotelapply", "\345\220\215\347\247\260", 0));
        label_2->setText(QApplication::translate("hotelapply", "\345\237\216\345\270\202", 0));
        label_3->setText(QApplication::translate("hotelapply", "\345\234\260\345\214\272", 0));
        apply->setText(QApplication::translate("hotelapply", "\347\224\263\350\257\267", 0));
        cancel->setText(QApplication::translate("hotelapply", "\345\217\226\346\266\210", 0));
        city->clear();
        city->insertItems(0, QStringList()
         << QApplication::translate("hotelapply", "\345\214\227\344\272\254", 0)
         << QApplication::translate("hotelapply", "\344\270\212\346\265\267", 0)
        );
        area->clear();
        area->insertItems(0, QStringList()
         << QApplication::translate("hotelapply", "\346\265\267\346\267\200\345\214\272", 0)
         << QApplication::translate("hotelapply", "\346\234\235\351\230\263\345\214\272", 0)
         << QApplication::translate("hotelapply", "\346\265\246\344\270\234", 0)
         << QApplication::translate("hotelapply", "\346\265\246\350\245\277", 0)
        );
    } // retranslateUi

};

namespace Ui {
    class hotelapply: public Ui_hotelapply {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HOTELAPPLY_H
