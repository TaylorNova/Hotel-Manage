/********************************************************************************
** Form generated from reading UI file 'register.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGISTER_H
#define UI_REGISTER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Register
{
public:
    QPushButton *confirm;
    QPushButton *cancel;
    QLineEdit *phonenum;
    QLineEdit *password;
    QLineEdit *passwordcon;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QComboBox *comboBox;
    QLabel *label_p;
    QLabel *label_w;
    QLabel *label_rw;
    QLabel *label_phone;
    QLabel *label_password;
    QLabel *label_passwordcon;
    QLabel *label_5;
    QLineEdit *manager_hotel;
    QLabel *label_6;

    void setupUi(QDialog *Register)
    {
        if (Register->objectName().isEmpty())
            Register->setObjectName(QStringLiteral("Register"));
        Register->resize(553, 391);
        confirm = new QPushButton(Register);
        confirm->setObjectName(QStringLiteral("confirm"));
        confirm->setGeometry(QRect(110, 330, 101, 41));
        confirm->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang4.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(213, 108, 15)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang6.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(244, 234, 41)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang7.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(153, 94, 30)\n"
"}"));
        cancel = new QPushButton(Register);
        cancel->setObjectName(QStringLiteral("cancel"));
        cancel->setGeometry(QRect(330, 330, 101, 41));
        cancel->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border-image: url(:/Image/kuang4.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(213, 108, 15)\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"border-image: url(:/Image/kuang6.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(244, 234, 41)\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"border-image: url(:/Image/kuang7.png);\n"
"font: 100 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";\n"
"color:rgb(153, 94, 30)\n"
"}"));
        phonenum = new QLineEdit(Register);
        phonenum->setObjectName(QStringLiteral("phonenum"));
        phonenum->setGeometry(QRect(160, 100, 201, 21));
        phonenum->setStyleSheet(QStringLiteral("border:2px groove gray;border-radius:10px;padding:2px 4px"));
        phonenum->setEchoMode(QLineEdit::Normal);
        password = new QLineEdit(Register);
        password->setObjectName(QStringLiteral("password"));
        password->setGeometry(QRect(160, 160, 201, 21));
        password->setStyleSheet(QStringLiteral("border:2px groove gray;border-radius:10px;padding:2px 4px"));
        password->setEchoMode(QLineEdit::Password);
        passwordcon = new QLineEdit(Register);
        passwordcon->setObjectName(QStringLiteral("passwordcon"));
        passwordcon->setGeometry(QRect(160, 220, 201, 21));
        passwordcon->setStyleSheet(QStringLiteral("border:2px groove gray;border-radius:10px;padding:2px 4px"));
        passwordcon->setEchoMode(QLineEdit::Password);
        label = new QLabel(Register);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(30, 100, 121, 21));
        label->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_2 = new QLabel(Register);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(60, 160, 71, 21));
        label_2->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_3 = new QLabel(Register);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(50, 220, 71, 21));
        label_3->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_4 = new QLabel(Register);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(40, 40, 81, 21));
        label_4->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        comboBox = new QComboBox(Register);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setEnabled(true);
        comboBox->setGeometry(QRect(160, 40, 201, 22));
        label_p = new QLabel(Register);
        label_p->setObjectName(QStringLiteral("label_p"));
        label_p->setGeometry(QRect(390, 100, 141, 16));
        label_p->setStyleSheet(QString::fromUtf8("font: 9pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_w = new QLabel(Register);
        label_w->setObjectName(QStringLiteral("label_w"));
        label_w->setGeometry(QRect(390, 160, 131, 16));
        label_w->setStyleSheet(QString::fromUtf8("font: 9pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_rw = new QLabel(Register);
        label_rw->setObjectName(QStringLiteral("label_rw"));
        label_rw->setGeometry(QRect(390, 220, 151, 20));
        label_rw->setStyleSheet(QString::fromUtf8("font: 9pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_phone = new QLabel(Register);
        label_phone->setObjectName(QStringLiteral("label_phone"));
        label_phone->setGeometry(QRect(390, 100, 111, 16));
        label_phone->setStyleSheet(QString::fromUtf8("font: 9pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_password = new QLabel(Register);
        label_password->setObjectName(QStringLiteral("label_password"));
        label_password->setGeometry(QRect(390, 160, 101, 16));
        label_password->setStyleSheet(QString::fromUtf8("font: 9pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_passwordcon = new QLabel(Register);
        label_passwordcon->setObjectName(QStringLiteral("label_passwordcon"));
        label_passwordcon->setGeometry(QRect(390, 220, 121, 16));
        label_passwordcon->setStyleSheet(QString::fromUtf8("font: 9pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        label_5 = new QLabel(Register);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(50, 270, 71, 21));
        label_5->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));
        manager_hotel = new QLineEdit(Register);
        manager_hotel->setObjectName(QStringLiteral("manager_hotel"));
        manager_hotel->setGeometry(QRect(160, 270, 201, 21));
        manager_hotel->setStyleSheet(QStringLiteral("border:2px groove gray;border-radius:10px;padding:2px 4px"));
        label_6 = new QLabel(Register);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(390, 270, 131, 16));
        label_6->setStyleSheet(QString::fromUtf8("font: 9pt \"\346\226\271\346\255\243\346\270\205\345\210\273\346\234\254\346\202\246\345\256\213\347\256\200\344\275\223\";"));

        retranslateUi(Register);
        QObject::connect(cancel, SIGNAL(clicked()), Register, SLOT(close()));

        QMetaObject::connectSlotsByName(Register);
    } // setupUi

    void retranslateUi(QDialog *Register)
    {
        Register->setWindowTitle(QApplication::translate("Register", "\346\263\250\345\206\214", 0));
        confirm->setText(QApplication::translate("Register", "\347\241\256\350\256\244", 0));
        cancel->setText(QApplication::translate("Register", "\345\217\226\346\266\210", 0));
        label->setText(QApplication::translate("Register", "\347\224\250\346\210\267\345\220\215\357\274\210\346\211\213\346\234\272\357\274\211", 0));
        label_2->setText(QApplication::translate("Register", "\345\257\206\347\240\201", 0));
        label_3->setText(QApplication::translate("Register", "\347\241\256\350\256\244\345\257\206\347\240\201", 0));
        label_4->setText(QApplication::translate("Register", "\347\224\250\346\210\267\347\261\273\345\236\213", 0));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("Register", "\351\241\276\345\256\242", 0)
         << QApplication::translate("Register", "\347\256\241\347\220\206\345\221\230", 0)
         << QApplication::translate("Register", "\351\205\222\345\272\227", 0)
        );
        comboBox->setCurrentText(QApplication::translate("Register", "\351\241\276\345\256\242", 0));
        label_p->setText(QApplication::translate("Register", "\350\257\267\350\276\223\345\205\24511\344\275\215\346\211\213\346\234\272\345\217\267", 0));
        label_w->setText(QApplication::translate("Register", "\351\225\277\345\272\246\344\270\215\345\260\217\344\272\2167\344\275\215", 0));
        label_rw->setText(QApplication::translate("Register", "\344\270\244\346\254\241\345\257\206\347\240\201\350\276\223\345\205\245\344\270\215\344\270\200\350\207\264", 0));
        label_phone->setText(QApplication::translate("Register", "\350\257\267\350\276\223\345\205\245\346\211\213\346\234\272\345\217\267", 0));
        label_password->setText(QApplication::translate("Register", "\350\257\267\350\276\223\345\205\245\345\257\206\347\240\201", 0));
        label_passwordcon->setText(QApplication::translate("Register", "\350\257\267\345\206\215\346\254\241\350\276\223\345\205\245\345\257\206\347\240\201", 0));
        label_5->setText(QApplication::translate("Register", "\346\211\200\345\234\250\351\205\222\345\272\227", 0));
        label_6->setText(QApplication::translate("Register", "\350\257\267\345\241\253\345\206\231\351\205\222\345\272\227\345\220\215", 0));
    } // retranslateUi

};

namespace Ui {
    class Register: public Ui_Register {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGISTER_H
