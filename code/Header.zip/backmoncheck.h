#ifndef BACKMONCHECK_H
#define BACKMONCHECK_H

#include <QDialog>

namespace Ui {
class backmoncheck;
}

class backmoncheck : public QDialog
{
    Q_OBJECT

public:
    explicit backmoncheck(QWidget *parent = 0);
    ~backmoncheck();

private slots:
    void on_cancel_clicked();

    void on_confirm_clicked();

private:
    Ui::backmoncheck *ui;
};

#endif // BACKMONCHECK_H
