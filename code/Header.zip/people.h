#ifndef PEOPLE_H
#define PEOPLE_H

#include "all_headers_nedded.h"
#include <iostream>
#include "Object.h"
using namespace std;

class People : public Object
{
public:
    People();
    ~People();
    virtual void set_identity(QString its_identity);
    virtual void set_password(QString its_password);
    virtual void set_phonenum(QString its_phonenum);
    virtual QString get_identity() const;
    virtual QString get_password() const;
    virtual QString get_phonenum() const;
    virtual void save_to_database_register();
    virtual bool load_from_database();
    QString identity = "";
    QString password = "";
    QString phonenum = "";
};

#endif // PEOPLE_H
