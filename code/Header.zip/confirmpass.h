#ifndef CONFIRMPASS_H
#define CONFIRMPASS_H

#include <QDialog>

namespace Ui {
class confirmpass;
}

class confirmpass : public QDialog
{
    Q_OBJECT

public:
    explicit confirmpass(QWidget *parent = 0);
    ~confirmpass();

private slots:
    void on_cancel_clicked();

    void on_confirm_clicked();

private:
    Ui::confirmpass *ui;
};

#endif // CONFIRMPASS_H
