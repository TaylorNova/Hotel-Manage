#ifndef CHECKORDER_H
#define CHECKORDER_H

#include <QDialog>

namespace Ui {
class checkorder;
}

class checkorder : public QDialog
{
    Q_OBJECT

public:
    explicit checkorder(QWidget *parent = 0);
    ~checkorder();
    void paintEvent(QPaintEvent *event) override;

private slots:
    void on_back_clicked();

    void on_backmonapply_clicked();

    void on_evaluate_clicked();

private:
    Ui::checkorder *ui;
};

#endif // CHECKORDER_H
