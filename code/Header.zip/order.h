#ifndef ORDER_H
#define ORDER_H

#include "all_headers_nedded.h"
#include <iostream>
#include "Object.h"
#include "Room.h"
using namespace std;

class Order :public Object
{
public:
    Order();
    ~Order();
    Order(Order &ord1);
    void set_pay_state(QString its_pay_state);
    void set_backmon_state(QString its_backmon_state);
    void set_stay_state(QString its_stay_state);
    void set_room(Room its_room);
    void set_fromtime(QString its_fromtime);
    void set_totime(QString its_totime);
    void set_roomcus(QString its_roomcus);
    void set_cusphonenum(QString its_cusphonenum);
    void set_hotel(QString its_hotel);
    void set_roomnum(int its_roomnum);
    QString get_pay_state() const;
    QString get_backmon_state() const;
    QString get_stay_state() const;
    QString get_fromtime() const;
    QString get_totime() const;
    QString get_roomcus() const;
    QString get_cusphonenum() const;
    QString get_hotel() const;
    int get_roomnum() const;
    Room & get_room();
private:
    QString hotel;
    QString pay_state;
    QString backmon_state;
    QString stay_state;
    Room room;
    QString fromtime;
    QString totime;
    QString roomcus;
    QString cusphonenum;
    int roomnum;
};

#endif // ORDER_H
